import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Post, Story, Reel, ChatThread, Language, Comment, Highlight, AppPermissions, AudioTrackOption } from '../types';
import { CURRENT_USER, INITIAL_USERS, INITIAL_POSTS, INITIAL_STORIES, INITIAL_REELS, INITIAL_CHATS, INITIAL_HIGHLIGHTS } from '../data/initialData';
import confetti from 'canvas-confetti';

interface AppContextType {
  currentUser: User;
  users: User[];
  posts: Post[];
  stories: Story[];
  reels: Reel[];
  chats: ChatThread[];
  savedPostIds: string[];
  activeTab: 'feed' | 'explore' | 'create' | 'reels' | 'profile' | 'messages';
  setActiveTab: (tab: 'feed' | 'explore' | 'create' | 'reels' | 'profile' | 'messages') => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  selectedStory: { stories: Story[]; initialIndex: number } | null;
  setSelectedStory: (story: { stories: Story[]; initialIndex: number } | null) => void;
  selectedChat: ChatThread | null;
  setSelectedChat: (chat: ChatThread | null) => void;
  isFestiveMode: boolean;
  toggleFestiveMode: () => void;
  triggerDesiCelebration: () => void;
  toggleLikePost: (postId: string) => void;
  toggleSavePost: (postId: string) => void;
  addCommentToPost: (postId: string, text: string) => void;
  deleteComment: (postId: string, commentId: string) => void;
  toggleFollowUser: (userId: string) => void;
  createNewPost: (post: Omit<Post, 'id' | 'likesCount' | 'comments' | 'timestamp' | 'isLiked' | 'isSaved'>) => void;
  createNewStory: (story: Omit<Story, 'id' | 'timestamp' | 'viewersCount' | 'seen'>) => void;
  createNewReel: (reel: Omit<Reel, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'isLiked' | 'isSaved'>) => void;
  repostItemToFeed: (item: {
    originalPostId?: string;
    originalUsername: string;
    originalAvatar: string;
    originalCaption: string;
    mediaUrl: string;
    mediaType?: 'image' | 'carousel';
    userNote?: string;
    isReel?: boolean;
    audioTrack?: { title: string; artist: string; cover?: string };
    hashtags?: string[];
  }) => void;
  addStoryHighlight: (highlight: Omit<Highlight, 'id' | 'createdAt'>) => void;
  deleteStoryHighlight: (highlightId: string) => void;
  selectedHighlight: Highlight | null;
  setSelectedHighlight: (highlight: Highlight | null) => void;
  showContactLogin: boolean;
  setShowContactLogin: (show: boolean) => void;
  appPermissions: AppPermissions;
  updateAppPermissions: (permissions: Partial<AppPermissions>) => void;
  followersModalState: { isOpen: boolean; type: 'followers' | 'following' | 'contacts'; targetUser?: User } | null;
  setFollowersModalState: (state: { isOpen: boolean; type: 'followers' | 'following' | 'contacts'; targetUser?: User } | null) => void;
  sendMessage: (chatId: string, text?: string, mediaUrl?: string, sticker?: string, isAudio?: boolean) => void;
  markStorySeen: (storyId: string) => void;
  switchUser: (userId: string) => void;
  updateProfile: (name: string, bio: string, location: string, avatar: string, badge?: string) => void;
  t: (key: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: {
    home: 'Home',
    explore: 'Explore',
    create: 'Create',
    reels: 'Reels',
    profile: 'Profile',
    messages: 'Messages',
    your_story: 'Your Story',
    add_story: 'Add Story',
    stories: 'Stories',
    trending_bharat: 'Trending Bharat',
    chai_time: 'Chai Time',
    desi_vibes: 'Desi Vibes',
    follow: 'Follow',
    following: 'Following',
    liked_by: 'Liked by',
    view_all_comments: 'View all comments',
    add_comment: 'Add a comment...',
    generate_caption: 'AI Desi Caption',
    share: 'Share',
    save: 'Save',
    search_placeholder: 'Search creators, #tags or Indian cities...',
    festive_mode: 'Festive Utsav Glow',
    namaste: 'Namaste',
    posts: 'Posts',
    followers: 'Followers',
    edit_profile: 'Edit Profile',
    switch_account: 'Switch Account',
    saved: 'Saved',
    send_message: 'Type a message...',
    desi_stickers: 'Desi Stickers',
  },
  hi: {
    home: 'होम',
    explore: 'खोजें',
    create: 'नया पोस्ट',
    reels: 'रील्स',
    profile: 'प्रोफ़ाइल',
    messages: 'बातचीत',
    your_story: 'आपकी कहानी',
    add_story: 'कहानी जोड़ें',
    stories: 'कहानियां',
    trending_bharat: 'ट्रेंडिंग भारत',
    chai_time: 'चाय की चुस्की',
    desi_vibes: 'देसी अंदाज़',
    follow: 'फॉलो करें',
    following: 'फॉलोइंग',
    liked_by: 'पसंद किया',
    view_all_comments: 'सभी टिप्पणियाँ देखें',
    add_comment: 'टिप्पणी लिखें...',
    generate_caption: 'AI देसी कैप्शन बनाएं',
    share: 'साझा करें',
    save: 'सहेजें',
    search_placeholder: 'क्रिएटर, #टैग या शहर खोजें...',
    festive_mode: 'उत्सव मोड',
    namaste: 'नमस्ते',
    posts: 'पोस्ट',
    followers: 'फॉलोअर्स',
    edit_profile: 'प्रोफ़ाइल बदलें',
    switch_account: 'अकाउंट बदलें',
    saved: 'सहेजे गए',
    send_message: 'संदेश लिखें...',
    desi_stickers: 'देसी स्टिकर्स',
  },
  hinglish: {
    home: 'Ghar / Feed',
    explore: 'Khoj',
    create: 'Naya Post',
    reels: 'Jhalak / Reels',
    profile: 'Meri Profile',
    messages: 'Baatcheet (DMs)',
    your_story: 'Apni Story',
    add_story: 'Story Lagao',
    stories: 'Kahaniyaan',
    trending_bharat: 'Trending Bharat 🔥',
    chai_time: 'Kadak Chai Pe Charcha ☕',
    desi_vibes: 'Desi Swag ✨',
    follow: 'Follow Karo',
    following: 'Dost (Following)',
    liked_by: 'Like kiya by',
    view_all_comments: 'Saare comments dekho',
    add_comment: 'Comment daalo bhai...',
    generate_caption: '✨ AI Desi Caption Generator',
    share: 'Bhejo',
    save: 'Save Rakho',
    search_placeholder: 'Dost, #hashtags ya Desi Sheher dhoondo...',
    festive_mode: 'Utsav Sparkle 🪔',
    namaste: 'Namaste Ji 🙏',
    posts: 'Posts',
    followers: 'Followers',
    edit_profile: 'Profile Edit Karo',
    switch_account: 'Dost Ka Account Dekho',
    saved: 'Saved Khazana',
    send_message: 'Baat karo...',
    desi_stickers: 'Desi Stickers Pack',
  },
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('insta_bharat_user');
    return saved ? JSON.parse(saved) : CURRENT_USER;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('insta_bharat_all_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('insta_bharat_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [stories, setStories] = useState<Story[]>(() => {
    const saved = localStorage.getItem('insta_bharat_stories');
    return saved ? JSON.parse(saved) : INITIAL_STORIES;
  });

  const [reels, setReels] = useState<Reel[]>(() => {
    const saved = localStorage.getItem('insta_bharat_reels');
    return saved ? JSON.parse(saved) : INITIAL_REELS;
  });

  const [chats, setChats] = useState<ChatThread[]>(() => {
    const saved = localStorage.getItem('insta_bharat_chats');
    return saved ? JSON.parse(saved) : INITIAL_CHATS;
  });

  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('insta_bharat_saved');
    return saved ? JSON.parse(saved) : ['post_2', 'post_3'];
  });

  const [activeTab, setActiveTab] = useState<'feed' | 'explore' | 'create' | 'reels' | 'profile' | 'messages'>('feed');
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('insta_bharat_lang') as Language;
    return saved || 'hinglish';
  });

  const [selectedStory, setSelectedStory] = useState<{ stories: Story[]; initialIndex: number } | null>(null);
  const [selectedChat, setSelectedChat] = useState<ChatThread | null>(null);
  const [isFestiveMode, setIsFestiveMode] = useState<boolean>(true);

  // App Permissions & Login at starting
  const [appPermissions, setAppPermissions] = useState<AppPermissions>(() => {
    const saved = localStorage.getItem('insta_bharat_permissions');
    return saved
      ? JSON.parse(saved)
      : {
          notifications: true,
          camera: true,
          contacts: true,
          isLoggedIn: false,
          phoneNumber: '98765 19470',
        };
  });

  const [showContactLogin, setShowContactLogin] = useState<boolean>(() => {
    const saved = localStorage.getItem('insta_bharat_permissions');
    if (!saved) return true; // Show contact login at starting!
    const parsed = JSON.parse(saved);
    return !parsed.isLoggedIn;
  });

  const [selectedHighlight, setSelectedHighlight] = useState<Highlight | null>(null);
  const [followersModalState, setFollowersModalState] = useState<{
    isOpen: boolean;
    type: 'followers' | 'following' | 'contacts';
    targetUser?: User;
  } | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('insta_bharat_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_permissions', JSON.stringify(appPermissions));
  }, [appPermissions]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_all_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_stories', JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_reels', JSON.stringify(reels));
  }, [reels]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_chats', JSON.stringify(chats));
  }, [chats]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_saved', JSON.stringify(savedPostIds));
  }, [savedPostIds]);

  useEffect(() => {
    localStorage.setItem('insta_bharat_lang', language);
  }, [language]);

  const t = (key: string): string => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS.en[key] || key;
  };

  const triggerDesiCelebration = () => {
    // Saffron, Marigold, Gulabi Pink, and Gold colors celebration!
    const colors = ['#F59E0B', '#EC4899', '#EF4444', '#10B981', '#EAB308', '#FF9933'];
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: colors,
      shapes: ['circle', 'square'],
      scalar: 1.1,
    });
  };

  const toggleFestiveMode = () => {
    setIsFestiveMode((prev) => {
      const next = !prev;
      if (next) {
        triggerDesiCelebration();
      }
      return next;
    });
  };

  const toggleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const isLiked = !p.isLiked;
          if (isLiked) {
            confetti({
              particleCount: 25,
              spread: 40,
              origin: { y: 0.7 },
              colors: ['#EC4899', '#F59E0B', '#EF4444'],
            });
          }
          return {
            ...p,
            isLiked,
            likesCount: isLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1),
          };
        }
        return p;
      })
    );
  };

  const toggleSavePost = (postId: string) => {
    setSavedPostIds((prev) => {
      const exists = prev.includes(postId);
      const next = exists ? prev.filter((id) => id !== postId) : [...prev, postId];
      setPosts((pList) =>
        pList.map((p) => (p.id === postId ? { ...p, isSaved: !exists } : p))
      );
      return next;
    });
  };

  const addCommentToPost = (postId: string, text: string) => {
    if (!text.trim()) return;
    const newComment: Comment = {
      id: `comment_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      text: text.trim(),
      timestamp: 'Just now',
      likesCount: 0,
      isLiked: false,
    };

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: [...p.comments, newComment],
          };
        }
        return p;
      })
    );
  };

  const deleteComment = (postId: string, commentId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: p.comments.filter((c) => c.id !== commentId),
          };
        }
        return p;
      })
    );
  };

  const toggleFollowUser = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const isFollowing = !u.isFollowing;
          return {
            ...u,
            isFollowing,
            followersCount: isFollowing ? u.followersCount + 1 : Math.max(0, u.followersCount - 1),
          };
        }
        return u;
      })
    );

    // Also update followingCount of currentUser
    setCurrentUser((prev) => {
      const targetUser = users.find((u) => u.id === userId);
      const isFollowing = targetUser?.isFollowing;
      return {
        ...prev,
        followingCount: isFollowing ? Math.max(0, prev.followingCount - 1) : prev.followingCount + 1,
      };
    });
  };

  const createNewPost = (newPostData: Omit<Post, 'id' | 'likesCount' | 'comments' | 'timestamp' | 'isLiked' | 'isSaved'>) => {
    const post: Post = {
      ...newPostData,
      id: `post_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      likesCount: 1,
      isLiked: true,
      isSaved: false,
      timestamp: 'Just now',
      comments: [],
    };

    setPosts((prev) => [post, ...prev]);
    setCurrentUser((prev) => ({ ...prev, postsCount: prev.postsCount + 1 }));
    triggerDesiCelebration();
    setActiveTab('feed');
  };

  const createNewStory = (storyData: Omit<Story, 'id' | 'timestamp' | 'viewersCount' | 'seen'>) => {
    const newStory: Story = {
      ...storyData,
      id: `story_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      timestamp: 'Just now',
      viewersCount: 1,
      seen: false,
    };

    setStories((prev) => [newStory, ...prev]);
    triggerDesiCelebration();
  };

  const createNewReel = (reelData: Omit<Reel, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'isLiked' | 'isSaved'>) => {
    const newReel: Reel = {
      ...reelData,
      id: `reel_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      isLiked: true,
      isSaved: false,
    };

    setReels((prev) => [newReel, ...prev]);
    triggerDesiCelebration();
    setActiveTab('reels');
  };

  const sendMessage = (chatId: string, text?: string, mediaUrl?: string, sticker?: string, isAudio?: boolean) => {
    const newMsg = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      text,
      mediaUrl,
      sticker,
      isAudio,
      audioDuration: isAudio ? '0:07' : undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChats((prev) =>
      prev.map((c) => {
        if (c.id === chatId) {
          const updatedMessages = [...c.messages, newMsg];
          const updatedChat = {
            ...c,
            lastMessage: newMsg,
            messages: updatedMessages,
          };
          if (selectedChat?.id === chatId) {
            setSelectedChat(updatedChat);
          }
          return updatedChat;
        }
        return c;
      })
    );

    // Simulate friendly Indian reply after 2 seconds
    setTimeout(() => {
      const replies = [
        'Arey kya baat hai! 🔥 Sahi scene hai!',
        'Chai peene chalte hain shaam ko? ☕',
        'Bilkul bhai! Shandar! ✨',
        'Zabardast click boss! 📸',
        'Namaste! Milte hain jaldi 🙏',
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];
      const botMsg = {
        id: `msg_bot_${Date.now()}`,
        senderId: 'participant',
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChats((prev) =>
        prev.map((c) => {
          if (c.id === chatId) {
            const updated = {
              ...c,
              lastMessage: botMsg,
              messages: [...c.messages, botMsg],
            };
            if (selectedChat?.id === chatId) {
              setSelectedChat(updated);
            }
            return updated;
          }
          return c;
        })
      );
    }, 2200);
  };

  const markStorySeen = (storyId: string) => {
    setStories((prev) =>
      prev.map((s) => (s.id === storyId ? { ...s, seen: true } : s))
    );
  };

  const switchUser = (userId: string) => {
    const found = users.find((u) => u.id === userId);
    if (found) {
      setCurrentUser(found);
    }
  };

  const updateAppPermissions = (permissions: Partial<AppPermissions>) => {
    setAppPermissions((prev) => {
      const updated = { ...prev, ...permissions };
      localStorage.setItem('insta_bharat_permissions', JSON.stringify(updated));
      return updated;
    });
  };

  const repostItemToFeed = (item: {
    originalPostId?: string;
    originalUsername: string;
    originalAvatar: string;
    originalCaption: string;
    mediaUrl: string;
    mediaType?: 'image' | 'carousel';
    userNote?: string;
    isReel?: boolean;
    audioTrack?: { title: string; artist: string; cover?: string };
    hashtags?: string[];
  }) => {
    const newRepostPost: Post = {
      id: `repost_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      mediaUrl: item.mediaUrl,
      mediaType: item.mediaType || 'image',
      caption: item.userNote
        ? `${item.userNote}\n\n[🔁 Desi Repost from @${item.originalUsername}]`
        : `🔁 Desi Repost from @${item.originalUsername}: "${item.originalCaption.slice(0, 100)}..."`,
      hashtags: item.hashtags || ['#DesiRepost', '#BharatVibes', '#TrendingBharat'],
      audioTrack: item.audioTrack,
      likesCount: 1,
      isLiked: true,
      isSaved: false,
      timestamp: 'Just now',
      comments: [],
      isRepost: true,
      repostInfo: {
        originalPostId: item.originalPostId,
        originalUsername: item.originalUsername,
        originalAvatar: item.originalAvatar,
        originalCaption: item.originalCaption,
        userNote: item.userNote,
        isReel: item.isReel,
      },
    };

    setPosts((prev) => [newRepostPost, ...prev]);
    setCurrentUser((prev) => ({ ...prev, postsCount: prev.postsCount + 1 }));
    triggerDesiCelebration();
    setActiveTab('feed');
  };

  const addStoryHighlight = (newHighlightData: Omit<Highlight, 'id' | 'createdAt'>) => {
    const newHl: Highlight = {
      ...newHighlightData,
      id: `hl_${Date.now()}`,
      createdAt: 'Just now',
    };

    setCurrentUser((prev) => {
      const existing = prev.highlights || [];
      const updatedHighlights = [newHl, ...existing];
      const updatedUser = { ...prev, highlights: updatedHighlights };
      setUsers((uList) => uList.map((u) => (u.id === prev.id ? updatedUser : u)));
      return updatedUser;
    });

    triggerDesiCelebration();
  };

  const deleteStoryHighlight = (highlightId: string) => {
    setCurrentUser((prev) => {
      const existing = prev.highlights || [];
      const updatedHighlights = existing.filter((h) => h.id !== highlightId);
      const updatedUser = { ...prev, highlights: updatedHighlights };
      setUsers((uList) => uList.map((u) => (u.id === prev.id ? updatedUser : u)));
      return updatedUser;
    });
  };

  const updateProfile = (name: string, bio: string, location: string, avatar: string, badge?: string) => {
    setCurrentUser((prev) => {
      const updated = { ...prev, name, bio, location, avatar, badge };
      setUsers((uList) => uList.map((u) => (u.id === prev.id ? updated : u)));
      return updated;
    });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        posts,
        stories,
        reels,
        chats,
        savedPostIds,
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        selectedStory,
        setSelectedStory,
        selectedChat,
        setSelectedChat,
        isFestiveMode,
        toggleFestiveMode,
        triggerDesiCelebration,
        toggleLikePost,
        toggleSavePost,
        addCommentToPost,
        deleteComment,
        toggleFollowUser,
        createNewPost,
        createNewStory,
        createNewReel,
        repostItemToFeed,
        addStoryHighlight,
        deleteStoryHighlight,
        selectedHighlight,
        setSelectedHighlight,
        showContactLogin,
        setShowContactLogin,
        appPermissions,
        updateAppPermissions,
        followersModalState,
        setFollowersModalState,
        sendMessage,
        markStorySeen,
        switchUser,
        updateProfile,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
