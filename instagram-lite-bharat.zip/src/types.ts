export type Language = 'en' | 'hi' | 'hinglish';

export interface User {
  id: string;
  username: string;
  name: string;
  avatar: string;
  bio: string;
  location: string;
  badge?: string; // e.g. "Chai Addict ☕", "Heritage Explorer 🏰", "Bollywood Buff 🎬"
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isVerified?: boolean;
  isFollowing?: boolean;
  stories?: Story[];
  highlights?: Highlight[];
  phoneNumber?: string;
}

export interface Highlight {
  id: string;
  title: string;
  cover: string;
  icon: string;
  storyIds?: string[];
  stories?: Story[];
  createdAt?: string;
}

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  email?: string;
  avatar: string;
  isRegistered: boolean;
  userId?: string;
  username?: string;
  isFollowing?: boolean;
  isOriginalContact?: boolean;
}

export interface Story {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  filter?: string;
  caption?: string;
  sticker?: string;
  audioTrack?: string;
  spotifySong?: AudioTrackOption;
  timestamp: string;
  viewersCount: number;
  seen?: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  text: string;
  timestamp: string;
  likesCount: number;
  isLiked?: boolean;
  isVerified?: boolean;
}

export interface Post {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  location?: string;
  mediaUrl: string;
  mediaType: 'image' | 'carousel';
  carouselImages?: string[];
  filter?: string;
  caption: string;
  shayari?: string; // Indian poetic couplet
  hashtags: string[];
  audioTrack?: {
    title: string;
    artist: string;
    duration?: string;
    spotifyId?: string;
    cover?: string;
  };
  likesCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  comments: Comment[];
  timestamp: string;
  desiStickers?: {
    id: string;
    type: string;
    emoji: string;
    x: number;
    y: number;
  }[];
  isRepost?: boolean;
  repostInfo?: {
    originalPostId?: string;
    originalUsername: string;
    originalAvatar: string;
    originalCaption?: string;
    userNote?: string;
    isReel?: boolean;
  };
  repostsCount?: number;
}

export interface Reel {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  audioTrack: {
    title: string;
    artist: string;
    cover?: string;
    spotifyId?: string;
  };
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  repostsCount?: number;
  isLiked?: boolean;
  isSaved?: boolean;
  isFollowing?: boolean;
  tags: string[];
}

export interface Message {
  id: string;
  senderId: string;
  text?: string;
  mediaUrl?: string;
  sticker?: string;
  isAudio?: boolean;
  audioDuration?: string;
  timestamp: string;
  reaction?: string;
}

export interface ChatThread {
  id: string;
  participant: User;
  lastMessage: Message;
  unreadCount: number;
  messages: Message[];
  statusText: string;
}

export interface FilterPreset {
  id: string;
  name: string;
  desiName: string;
  cssFilter: string;
  overlayGradient?: string;
}

export interface DesiSticker {
  id: string;
  name: string;
  emoji: string;
  category: 'chai' | 'festive' | 'swag' | 'heritage' | 'food';
}

export interface AudioTrackOption {
  id: string;
  title: string;
  artist: string;
  mood: string;
  cover: string;
  duration?: string;
  spotifyUri?: string;
  isSpotifyHit?: boolean;
  genre?: 'Bollywood' | 'Indie Desi' | 'Classical & Sufi' | 'Punjabi Dhol' | 'Tapri Lo-Fi';
  album?: string;
}

export interface AppPermissions {
  notifications: boolean;
  camera: boolean;
  contacts: boolean;
  isLoggedIn: boolean;
  phoneNumber?: string;
}

