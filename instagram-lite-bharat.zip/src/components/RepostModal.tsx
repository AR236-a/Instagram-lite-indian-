import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Post, Reel } from '../types';
import { X, Repeat, Sparkles, Send, MessageCircle } from 'lucide-react';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';

interface RepostModalProps {
  isOpen: boolean;
  onClose: () => void;
  post?: Post;
  reel?: Reel;
}

export const RepostModal: React.FC<RepostModalProps> = ({ isOpen, onClose, post, reel }) => {
  const { repostItemToFeed, currentUser } = useApp();
  const [userNote, setUserNote] = useState('');

  if (!isOpen || (!post && !reel)) return null;

  const originalUsername = post?.username || reel?.username || '';
  const originalAvatar = post?.userAvatar || reel?.userAvatar || '';
  const originalCaption = post?.caption || reel?.caption || '';
  const mediaUrl = post?.mediaUrl || reel?.videoUrl || '';
  const isReel = !!reel;
  const audioTrack = post?.audioTrack || (reel?.audioTrack ? { title: reel.audioTrack, artist: 'Original Soundtrack' } : undefined);

  const DESI_QUICK_REMARKS = [
    'Pure sukoon & vibes! ☕✨',
    'Dil jeet liya boss! ❤️🇮🇳',
    'Must watch for everyone! 🔥',
    'Proud of our Bharat heritage! 🪔',
    'Kya baat hai, zabardast! 👏',
  ];

  const handleRepost = (e: React.FormEvent) => {
    e.preventDefault();

    repostItemToFeed({
      originalPostId: post?.id || reel?.id,
      originalUsername,
      originalAvatar,
      originalCaption,
      mediaUrl,
      mediaType: post?.mediaType || 'image',
      userNote: userNote.trim() || undefined,
      isReel,
      audioTrack,
      hashtags: post?.hashtags || ['#DesiRepost', '#TrendingBharat', '#DesiVibes'],
    });

    setUserNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-white border border-orange-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#FF9933]/10 via-[#F59E0B]/10 to-orange-50 border-b border-orange-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#FF9933] to-[#D97706] flex items-center justify-center text-white shadow-xs">
              <Repeat className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">Repost to Public Feed</h3>
              <p className="text-[11px] text-gray-500">Share with credit to original creator</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-orange-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleRepost} className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Original Post Preview Card */}
          <div className="p-3 rounded-2xl bg-[#FFFAF5] border border-orange-100/90 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={originalAvatar}
                  alt={originalUsername}
                  className="w-7 h-7 rounded-full object-cover border border-orange-200"
                />
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-gray-900">@{originalUsername}</span>
                  <DesiVerifiedBadge size="xs" />
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 text-[#D97706] font-bold">
                {isReel ? 'Reel 🎬' : 'Post 📸'}
              </span>
            </div>

            <div className="relative aspect-video rounded-xl overflow-hidden bg-neutral-900 border border-orange-100">
              <img src={mediaUrl} alt="Preview" className="w-full h-full object-cover" />
            </div>

            <p className="text-xs text-gray-700 line-clamp-2 italic">
              "{originalCaption}"
            </p>
          </div>

          {/* User Thought / Note Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-800">
              Your Reaction Note (Optional)
            </label>
            <textarea
              rows={2}
              value={userNote}
              onChange={(e) => setUserNote(e.target.value)}
              placeholder="Why are you reposting this? Add your thoughts..."
              className="w-full bg-[#FFFAF5] border border-orange-200 rounded-2xl p-3 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />
          </div>

          {/* Quick Desi Remark Chips */}
          <div className="flex flex-wrap gap-1.5">
            {DESI_QUICK_REMARKS.map((remark) => (
              <button
                type="button"
                key={remark}
                onClick={() => setUserNote(remark)}
                className="px-2.5 py-1 rounded-full bg-orange-50 hover:bg-orange-100 text-[11px] text-[#D97706] font-medium border border-orange-200 transition-colors"
              >
                {remark}
              </button>
            ))}
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity flex items-center justify-center gap-1.5"
          >
            <Repeat className="w-4 h-4" />
            <span>Repost on My Public Account 🇮🇳</span>
          </button>
        </form>
      </div>
    </div>
  );
};
