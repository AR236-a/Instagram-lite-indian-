import React, { useState } from 'react';
import { AudioTrackOption } from '../types';
import { Search, Play, Pause, Music, Check, Sparkles, Volume2, X } from 'lucide-react';

export const SPOTIFY_INDIAN_TRACKS: AudioTrackOption[] = [
  {
    id: 'sp_1',
    title: 'Kesariya (Brahmāstra)',
    artist: 'Arijit Singh, Pritam, Amitabh Bhattacharya',
    mood: 'Romantic Saffron Glow 🧡',
    cover: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=300&auto=format&fit=crop&q=80',
    duration: '2:52',
    isSpotifyHit: true,
    genre: 'Bollywood',
    album: 'Spotify Top 50 India',
  },
  {
    id: 'sp_2',
    title: 'Kahani Suno 2.0',
    artist: 'Kaifi Khalil',
    mood: 'Soulful & Melancholy 🥀',
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
    duration: '2:54',
    isSpotifyHit: true,
    genre: 'Indie Desi',
    album: 'Indie India Viral',
  },
  {
    id: 'sp_3',
    title: 'Khalasi (Coke Studio Bharat)',
    artist: 'Aditya Gadhvi, Achint',
    mood: 'Garba & Gujarati Folk Swag 🪘',
    cover: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=300&auto=format&fit=crop&q=80',
    duration: '3:15',
    isSpotifyHit: true,
    genre: 'Classical & Sufi',
    album: 'Coke Studio Bharat Vol 1',
  },
  {
    id: 'sp_4',
    title: 'Chai & Mumbai Monsoons Lo-Fi',
    artist: 'Indian Ocean Vibes, Tapri Beats',
    mood: 'Rain, Kadak Chai & Sukoon ☕',
    cover: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=300&auto=format&fit=crop&q=80',
    duration: '2:18',
    isSpotifyHit: true,
    genre: 'Tapri Lo-Fi',
    album: 'Desi Chill Essentials',
  },
  {
    id: 'sp_5',
    title: 'Lover • MoonChild Era',
    artist: 'Diljit Dosanjh, Intense',
    mood: 'Punjabi Romantic Swag 🕺',
    cover: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=300&auto=format&fit=crop&q=80',
    duration: '3:04',
    isSpotifyHit: true,
    genre: 'Punjabi Dhol',
    album: 'Punjabi 101 Hits',
  },
  {
    id: 'sp_6',
    title: 'Liggi • Tabla & Bass',
    artist: 'Ritviz',
    mood: 'Electronic Folk & Wedding Vibes ✨',
    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
    duration: '3:01',
    isSpotifyHit: true,
    genre: 'Indie Desi',
    album: 'Ritviz Hits',
  },
  {
    id: 'sp_7',
    title: 'Kun Faya Kun (Rockstar)',
    artist: 'A.R. Rahman, Javed Ali, Mohit Chauhan',
    mood: 'Sufi Transcendence & Peace 🪔',
    cover: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=300&auto=format&fit=crop&q=80',
    duration: '4:20',
    isSpotifyHit: true,
    genre: 'Classical & Sufi',
    album: 'Rahman Divine Melodies',
  },
  {
    id: 'sp_8',
    title: 'Genda Phool (Delhi 6 Flute Mix)',
    artist: 'Rekha Bhardwaj, Shraddha Pandit',
    mood: 'Jaipur Heritage & Marigold 🌼',
    cover: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=300&auto=format&fit=crop&q=80',
    duration: '2:45',
    isSpotifyHit: true,
    genre: 'Bollywood',
    album: 'Heritage Melodies',
  },
];

interface SpotifyMusicPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTrack: (track: AudioTrackOption) => void;
  currentTrackId?: string;
}

export const SpotifyMusicPickerModal: React.FC<SpotifyMusicPickerModalProps> = ({
  isOpen,
  onClose,
  onSelectTrack,
  currentTrackId,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [playingId, setPlayingId] = useState<string | null>(currentTrackId || null);

  if (!isOpen) return null;

  const genres = ['All', 'Bollywood', 'Indie Desi', 'Classical & Sufi', 'Punjabi Dhol', 'Tapri Lo-Fi'];

  const filteredTracks = SPOTIFY_INDIAN_TRACKS.filter((track) => {
    const matchesSearch =
      track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.mood.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'All' || track.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  const togglePlay = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPlayingId(playingId === id ? null : id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-lg bg-white border border-orange-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-200">
        {/* Header with Spotify & Bharat Theme */}
        <div className="p-4 bg-gradient-to-r from-[#1DB954]/10 via-[#FF9933]/10 to-orange-50 border-b border-orange-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#1DB954] flex items-center justify-center text-white shadow-xs">
              {/* Spotify Icon */}
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.061-.779-.179-.839-.539-.06-.421.18-.78.54-.84 4.56-1.021 8.52-.6 11.64 1.32.42.18.48.66.241 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-gray-900">Spotify India Soundtracks</h3>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#1DB954]/15 text-[#15803D] font-bold">
                  Official Tracks
                </span>
              </div>
              <p className="text-[11px] text-gray-500">Attach trending Bollywood, Indie & Tapri tunes 🎶</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-orange-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="p-3.5 border-b border-orange-100 bg-[#FFFAF5] space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-[#FF9933] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by song name, artist (Arijit, Ritviz, Diljit) or mood..."
              className="w-full bg-white border border-orange-200/80 rounded-2xl pl-10 pr-4 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933] shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Genre Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {genres.map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={`px-3 py-1 rounded-full text-[11px] font-bold whitespace-nowrap transition-all ${
                  selectedGenre === g
                    ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                    : 'bg-white text-gray-600 border border-orange-100 hover:bg-orange-50'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Tracks List */}
        <div className="flex-1 overflow-y-auto divide-y divide-orange-50 p-2">
          {filteredTracks.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-400 space-y-2">
              <Music className="w-8 h-8 mx-auto text-orange-300 animate-bounce" />
              <p>No tracks found matching "{searchQuery}". Try "Arijit" or "Chai".</p>
            </div>
          ) : (
            filteredTracks.map((track) => {
              const isSelected = track.id === currentTrackId;
              const isPlaying = playingId === track.id;

              return (
                <div
                  key={track.id}
                  onClick={() => {
                    onSelectTrack(track);
                    onClose();
                  }}
                  className={`p-2.5 rounded-2xl flex items-center justify-between gap-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-orange-100/70 border border-orange-300 shadow-2xs'
                      : 'hover:bg-orange-50/70'
                  }`}
                >
                  {/* Left Track Artwork & Details */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 border border-orange-200">
                      <img src={track.cover} alt={track.title} className="w-full h-full object-cover" />

                      {/* Play/Pause Button Overlay */}
                      <button
                        onClick={(e) => togglePlay(track.id, e)}
                        className="absolute inset-0 bg-black/40 hover:bg-black/60 flex items-center justify-center text-white transition-colors"
                        title={isPlaying ? 'Pause snippet' : 'Play snippet'}
                      >
                        {isPlaying ? (
                          <Pause className="w-4 h-4 text-[#1DB954] fill-current" />
                        ) : (
                          <Play className="w-4 h-4 ml-0.5" />
                        )}
                      </button>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-bold text-gray-900 truncate">{track.title}</p>
                        {track.isSpotifyHit && (
                          <span className="w-2 h-2 rounded-full bg-[#1DB954]" title="Spotify Verified Track" />
                        )}
                      </div>
                      <p className="text-[11px] text-gray-500 truncate">{track.artist}</p>
                      <p className="text-[10px] text-[#D97706] font-medium truncate mt-0.5">{track.mood}</p>
                    </div>
                  </div>

                  {/* Right: Wave indicator & Select CTA */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {isPlaying && (
                      <div className="flex items-center gap-0.5">
                        <div className="w-1 h-3 bg-[#1DB954] rounded-full animate-pulse" />
                        <div className="w-1 h-5 bg-[#FF9933] rounded-full animate-pulse delay-75" />
                        <div className="w-1 h-2 bg-[#1DB954] rounded-full animate-pulse delay-150" />
                      </div>
                    )}

                    <span className="text-[10px] text-gray-400 font-medium">{track.duration}</span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTrack(track);
                        onClose();
                      }}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${
                        isSelected
                          ? 'bg-[#15803D] text-white shadow-xs'
                          : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] hover:opacity-90 text-white shadow-2xs'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Attached</span>
                        </>
                      ) : (
                        <span>Add Song</span>
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Info */}
        <div className="p-3 bg-[#FFFAF5] border-t border-orange-100 flex items-center justify-between text-[11px] text-gray-500">
          <div className="flex items-center gap-1.5 text-[#1DB954] font-bold">
            <Volume2 className="w-3.5 h-3.5" />
            <span>High Quality 320kbps Audio Sync</span>
          </div>
          <span className="text-gray-400">Powered by Spotify Bharat 🇮🇳</span>
        </div>
      </div>
    </div>
  );
};
