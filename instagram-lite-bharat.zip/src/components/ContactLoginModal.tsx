import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ContactItem, User } from '../types';
import { Phone, ShieldCheck, Bell, Camera, Users, Check, Sparkles, ArrowRight, UserCheck, Heart, Coffee } from 'lucide-react';
import confetti from 'canvas-confetti';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';

export const SAMPLE_CONTACTS: ContactItem[] = [
  {
    id: 'c_arnav',
    name: 'Arnav Anand (Original Contact)',
    phone: '+91 98765 04040',
    email: 'arnavanand040@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_arnav',
    username: 'arnav_anand',
    isFollowing: true,
    isOriginalContact: true,
  },
  {
    id: 'c1',
    name: 'Priya Sharma (Jaipur)',
    phone: '+91 98765 43210',
    email: 'priya.sharma@desimail.in',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_priya',
    username: 'priya.in.saree',
    isFollowing: true,
  },
  {
    id: 'c2',
    name: 'Aarav Mehta (Manali Trips)',
    phone: '+91 98234 56789',
    email: 'aarav.wanderlust@himalayas.in',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_aarav',
    username: 'aarav_wanderlust',
    isFollowing: true,
  },
  {
    id: 'c3',
    name: 'Ananya Roy (Delhi Foodie)',
    phone: '+91 99123 45678',
    email: 'ananya.delhifood@desimail.in',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_ananya',
    username: 'delhi_foodie_ananya',
    isFollowing: true,
  },
  {
    id: 'c4',
    name: 'Rohan Deshmukh (Tabla Producer)',
    phone: '+91 97890 12345',
    email: 'rohan.beats@mumbaimusic.in',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_rohan',
    username: 'rohan_beats',
    isFollowing: false,
  },
  {
    id: 'c5',
    name: 'Meera Iyer (Ghats of Kashi)',
    phone: '+91 98321 09876',
    email: 'meera.kashi@ghats.in',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_meera',
    username: 'meera_varanasi',
    isFollowing: false,
  },
  {
    id: 'c6',
    name: 'Vikram Singh (Jaipur Royal)',
    phone: '+91 98456 71234',
    email: 'vikram.royal@jaipur.in',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&auto=format&fit=crop&q=80',
    isRegistered: true,
    userId: 'user_vikram',
    username: 'vikram.royal',
    isFollowing: false,
  },
];

interface ContactLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactLoginModal: React.FC<ContactLoginModalProps> = ({ isOpen, onClose }) => {
  const {
    currentUser,
    users,
    toggleFollowUser,
    appPermissions,
    updateAppPermissions,
    triggerDesiCelebration,
    switchUser,
  } = useApp();

  const [step, setStep] = useState<'phone' | 'otp' | 'permissions' | 'contacts'>('phone');
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phoneNumber || '98765 19470');
  const [otp, setOtp] = useState('');
  const [notificationsGranted, setNotificationsGranted] = useState(appPermissions.notifications);
  const [cameraGranted, setCameraGranted] = useState(appPermissions.camera);
  const [contactsGranted, setContactsGranted] = useState(appPermissions.contacts);
  const [contactList, setContactList] = useState<ContactItem[]>(SAMPLE_CONTACTS);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 6) return;
    setStep('otp');
    setOtp('1947'); // Auto-fill standard Indian patriotic OTP
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    triggerDesiCelebration();
    setStep('permissions');
  };

  const handleSavePermissions = () => {
    updateAppPermissions({
      notifications: notificationsGranted,
      camera: cameraGranted,
      contacts: contactsGranted,
      isLoggedIn: true,
      phoneNumber: `+91 ${phoneNumber}`,
    });

    if (contactsGranted) {
      setStep('contacts');
    } else {
      triggerDesiCelebration();
      onClose();
    }
  };

  const handleToggleContactFollow = (contact: ContactItem) => {
    if (contact.userId) {
      toggleFollowUser(contact.userId);
      setContactList((prev) =>
        prev.map((c) => (c.id === contact.id ? { ...c, isFollowing: !c.isFollowing } : c))
      );
      confetti({
        particleCount: 20,
        spread: 40,
        colors: ['#FF9933', '#10B981'],
      });
    }
  };

  const handleSelectQuickContact = (c: ContactItem) => {
    setPhoneNumber(c.phone.replace('+91 ', ''));
    if (c.userId) {
      switchUser(c.userId);
    }
    setStep('otp');
    setOtp('1947');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-white border border-orange-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Desi Top Banner */}
        <div className="p-5 bg-gradient-to-r from-[#FF9933] via-[#F59E0B] to-[#D97706] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-xs">
              <span className="text-xl">🇮🇳</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-bold font-serif">Instagram Lite Bharat</h2>
                <DesiVerifiedBadge size="xs" />
              </div>
              <p className="text-[11px] text-orange-100 font-medium">My Contact Login & Desi Sync</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white text-xs transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-2.5 bg-[#FFFAF5] border-b border-orange-100 flex items-center justify-between text-[11px] text-gray-500 font-medium">
          <span className={step === 'phone' ? 'text-[#D97706] font-bold' : ''}>1. Mobile Login</span>
          <span>→</span>
          <span className={step === 'otp' ? 'text-[#D97706] font-bold' : ''}>2. SMS OTP</span>
          <span>→</span>
          <span className={step === 'permissions' ? 'text-[#D97706] font-bold' : ''}>3. Access Setup</span>
          <span>→</span>
          <span className={step === 'contacts' ? 'text-[#D97706] font-bold' : ''}>4. Follow Friends</span>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto max-h-[75vh]">
          {/* STEP 1: Phone Number Input */}
          {step === 'phone' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 mx-auto rounded-full bg-orange-50 border border-orange-200 flex items-center justify-center text-[#D97706]">
                  <Phone className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-gray-900">Enter your Mobile Number</h3>
                <p className="text-xs text-gray-500">
                  Instant login via WhatsApp / Indian SMS OTP. Fast, lightweight & battery safe.
                </p>
              </div>

              <form onSubmit={handleSendOtp} className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="px-3 py-2.5 bg-orange-50/80 border border-orange-200 rounded-2xl text-xs font-bold text-gray-800 flex items-center gap-1">
                    <span>🇮🇳</span>
                    <span>+91</span>
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="98765 43210"
                    required
                    className="flex-1 bg-[#FFFAF5] border border-orange-200 rounded-2xl px-4 py-2.5 text-sm font-semibold text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity flex items-center justify-center gap-1.5"
                >
                  <span>Get Desi OTP</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Quick Select From My Contacts */}
              <div className="pt-2 border-t border-orange-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-gray-700">Or Login with Saved Phonebook:</span>
                  <span className="text-[10px] text-[#D97706] font-bold">1-Tap Fast Switch</span>
                </div>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {SAMPLE_CONTACTS.slice(0, 3).map((c) => (
                    <div
                      key={c.id}
                      onClick={() => handleSelectQuickContact(c)}
                      className="p-2 rounded-xl bg-orange-50/50 hover:bg-orange-100/70 border border-orange-100 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <img src={c.avatar} alt={c.name} className="w-7 h-7 rounded-full object-cover border border-orange-200" />
                        <div>
                          <p className="text-xs font-bold text-gray-900">{c.name}</p>
                          <p className="text-[10px] text-gray-500">{c.phone}</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-[#D97706]">Tap to Login →</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: OTP Verification */}
          {step === 'otp' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-gray-900">Verify 4-Digit OTP</h3>
                <p className="text-xs text-gray-500">
                  Sent to <span className="font-bold text-gray-800">+91 {phoneNumber}</span>
                </p>
              </div>

              <form onSubmit={handleVerifyOtp} className="space-y-3">
                <div className="flex justify-center gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="1 9 4 7"
                    className="w-48 tracking-[1em] text-center font-mono text-xl font-bold bg-[#FFFAF5] border-2 border-orange-300 rounded-2xl py-2 text-gray-900 focus:outline-none focus:border-[#FF9933]"
                  />
                </div>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => setOtp('1947')}
                    className="text-[11px] text-[#D97706] font-bold hover:underline"
                  >
                    Auto-Fill Freedom OTP (1947) 🇮🇳
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity"
                >
                  Verify & Continue
                </button>
              </form>
            </div>
          )}

          {/* STEP 3: Permissions Gateway (Notifications, Camera, Contacts) */}
          {step === 'permissions' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 mx-auto rounded-full bg-orange-50 border border-orange-200 flex items-center justify-center text-[#D97706]">
                  <Sparkles className="w-6 h-6 animate-spin-slow" />
                </div>
                <h3 className="text-sm font-bold text-gray-900">App Permissions for Bharat Experience</h3>
                <p className="text-xs text-gray-500">
                  Please enable notifications, camera, and contacts for full social connectivity.
                </p>
              </div>

              <div className="space-y-2.5">
                {/* 1. Notifications Permission */}
                <div className="p-3 rounded-2xl bg-[#FFFAF5] border border-orange-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-orange-100 text-[#D97706] flex items-center justify-center">
                      <Bell className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900">Push Notifications</p>
                      <p className="text-[10px] text-gray-500">Utsav alerts, likes, comments & story tags</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setNotificationsGranted(!notificationsGranted)}
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                      notificationsGranted ? 'bg-[#10B981]' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                        notificationsGranted ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* 2. Camera & Mic Permission */}
                <div className="p-3 rounded-2xl bg-[#FFFAF5] border border-orange-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                      <Camera className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900">Camera & Microphone</p>
                      <p className="text-[10px] text-gray-500">Create Desi Stories, Reels & apply filters</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setCameraGranted(!cameraGranted)}
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                      cameraGranted ? 'bg-[#10B981]' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                        cameraGranted ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* 3. Contacts Permission */}
                <div className="p-3 rounded-2xl bg-[#FFFAF5] border border-orange-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900">Phone Contacts Access</p>
                      <p className="text-[10px] text-gray-500">Discover & follow friends from your phonebook</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setContactsGranted(!contactsGranted)}
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                      contactsGranted ? 'bg-[#10B981]' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                        contactsGranted ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <button
                onClick={handleSavePermissions}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity flex items-center justify-center gap-1.5"
              >
                <span>Save Permissions & Proceed</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 4: Discover & Follow Contacts */}
          {step === 'contacts' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                  <UserCheck className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-gray-900">Found 6 Friends in Contacts!</h3>
                <p className="text-xs text-gray-500">
                  Connect with your real-life circle on Instagram Lite Bharat.
                </p>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {contactList.map((contact) => (
                  <div
                    key={contact.id}
                    className="p-2.5 rounded-2xl bg-[#FFFAF5] border border-orange-100 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={contact.avatar}
                        alt={contact.name}
                        className="w-9 h-9 rounded-full object-cover border border-orange-200 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold text-gray-900 truncate">{contact.name}</p>
                          <DesiVerifiedBadge size="xs" />
                        </div>
                        <p className="text-[10px] text-gray-500">@{contact.username} • {contact.phone}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleToggleContactFollow(contact)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 flex-shrink-0 ${
                        contact.isFollowing
                          ? 'bg-orange-100 text-[#D97706] border border-orange-200'
                          : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                      }`}
                    >
                      {contact.isFollowing ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Dost (Following)</span>
                        </>
                      ) : (
                        <span>+ Follow</span>
                      )}
                    </button>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  triggerDesiCelebration();
                  onClose();
                }}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity"
              >
                Go to Bharat Feed 🇮🇳
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
