import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Send, Mic, Smile, Phone, Video, CheckCheck } from 'lucide-react';
import { DESI_STICKERS } from '../data/initialData';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';

export const DirectMessages: React.FC = () => {
  const {
    chats,
    selectedChat,
    setSelectedChat,
    sendMessage,
    currentUser,
    setActiveTab,
    t,
  } = useApp();

  const [messageInput, setMessageInput] = useState('');
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [searchFriend, setSearchFriend] = useState('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedChat?.messages]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !selectedChat) return;

    sendMessage(selectedChat.id, messageInput);
    setMessageInput('');
  };

  const handleSendSticker = (stickerEmoji: string, stickerName: string) => {
    if (!selectedChat) return;
    sendMessage(selectedChat.id, undefined, undefined, `${stickerEmoji} ${stickerName}`);
    setShowStickerPicker(false);
    confetti({
      particleCount: 20,
      spread: 40,
      origin: { y: 0.8 },
      colors: ['#FF9933', '#EC4899'],
    });
  };

  const handleSendVoiceNote = () => {
    if (!selectedChat) return;
    setIsRecordingAudio(true);
    setTimeout(() => {
      setIsRecordingAudio(false);
      sendMessage(selectedChat.id, undefined, undefined, undefined, true);
    }, 1500);
  };

  const filteredChats = chats.filter((c) =>
    c.participant.name.toLowerCase().includes(searchFriend.toLowerCase()) ||
    c.participant.username.toLowerCase().includes(searchFriend.toLowerCase())
  );

  return (
    <div className="w-full max-w-xl mx-auto h-[calc(100vh-130px)] max-h-[750px] bg-white border border-orange-100/90 rounded-2xl overflow-hidden shadow-xl flex flex-col">
      {!selectedChat ? (
        /* Conversation List View */
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-orange-100 flex items-center justify-between bg-[#FFFAF5]">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-gray-900">
                Baatcheet (DMs) 💬
              </span>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-orange-100/80 text-[#D97706] font-bold border border-orange-200/80">
                Desi Friends
              </span>
            </div>
            <button
              onClick={() => setActiveTab('feed')}
              className="text-xs text-gray-500 hover:text-[#D97706] font-medium"
            >
              Back to Feed
            </button>
          </div>

          {/* Search Contacts */}
          <div className="p-3 border-b border-orange-50 bg-white">
            <input
              type="text"
              value={searchFriend}
              onChange={(e) => setSearchFriend(e.target.value)}
              placeholder="Search Indian friends..."
              className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl px-3.5 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />
          </div>

          {/* Chat Threads */}
          <div className="flex-1 overflow-y-auto divide-y divide-orange-50">
            {filteredChats.map((chat) => (
              <div
                key={chat.id}
                onClick={() => setSelectedChat(chat)}
                className="p-3.5 flex items-center justify-between hover:bg-orange-50/70 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={chat.participant.avatar}
                      alt={chat.participant.name}
                      className="w-11 h-11 rounded-full object-cover border border-orange-200"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-gray-900">
                        {chat.participant.name}
                      </span>
                      <span className="text-[10px] text-[#D97706] font-medium">
                        @{chat.participant.username}
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-600 truncate max-w-[200px] mt-0.5">
                      {chat.lastMessage.text || (chat.lastMessage.isAudio ? '🎙️ Desi Voice Note' : '✨ Sticker')}
                    </p>
                    <span className="text-[9px] text-gray-400 italic block mt-0.5">
                      {chat.statusText}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1">
                  <span className="text-[10px] text-gray-400">
                    {chat.lastMessage.timestamp}
                  </span>
                  {chat.unreadCount > 0 && (
                    <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Active Chat View */
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Active Chat Header */}
          <div className="px-3.5 py-2.5 bg-[#FFFAF5] border-b border-orange-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSelectedChat(null)}
                className="p-1 rounded-lg text-gray-500 hover:text-gray-900 hover:bg-orange-100/60"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <img
                src={selectedChat.participant.avatar}
                alt={selectedChat.participant.name}
                className="w-8 h-8 rounded-full object-cover border border-orange-200"
              />
              <div>
                <p className="text-xs font-bold text-gray-900 leading-tight">
                  {selectedChat.participant.name}
                </p>
                <p className="text-[10px] text-[#D97706] font-medium">
                  {selectedChat.statusText}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 text-gray-500">
              <button className="p-1.5 hover:text-[#D97706]">
                <Phone className="w-4 h-4" />
              </button>
              <button className="p-1.5 hover:text-[#D97706]">
                <Video className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Bubble List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#FFF9F2]/50">
            {selectedChat.messages.map((msg) => {
              const isMe = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[75%] px-3.5 py-2 rounded-2xl text-xs leading-relaxed ${
                      isMe
                        ? 'bg-gradient-to-tr from-[#FF9933] to-[#D97706] text-white rounded-br-none shadow-xs'
                        : 'bg-white text-gray-900 rounded-bl-none border border-orange-100 shadow-2xs'
                    }`}
                  >
                    {msg.text && <p>{msg.text}</p>}

                    {msg.sticker && (
                      <div className="text-2xl py-1 text-center font-bold">
                        {msg.sticker}
                      </div>
                    )}

                    {msg.isAudio && (
                      <div className="flex items-center gap-2 py-0.5">
                        <Mic className="w-4 h-4 text-orange-200 animate-pulse" />
                        <span className="font-semibold text-[11px]">Desi Voice Note</span>
                        <span className="text-[10px] opacity-80">(0:07)</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 mt-0.5 px-1">
                    <span className="text-[9px] text-gray-400">{msg.timestamp}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-[#D97706]" />}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Desi Stickers Picker Drawer */}
          <AnimatePresence>
            {showStickerPicker && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="bg-[#FFFAF5] border-t border-orange-100 p-3 overflow-hidden"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-[#D97706]">
                    Desi Cultural Stickers & Emojis ✨
                  </span>
                  <button
                    onClick={() => setShowStickerPicker(false)}
                    className="text-gray-400 text-xs hover:text-gray-700"
                  >
                    ✕
                  </button>
                </div>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                  {DESI_STICKERS.map((st) => (
                    <button
                      key={st.id}
                      onClick={() => handleSendSticker(st.emoji, st.name)}
                      className="p-2 rounded-xl bg-white hover:bg-orange-50 text-center flex flex-col items-center gap-1 border border-orange-100 hover:border-orange-300 transition-all hover:scale-105 shadow-2xs"
                    >
                      <span className="text-xl">{st.emoji}</span>
                      <span className="text-[9px] text-gray-700 font-medium truncate w-full">
                        {st.name}
                      </span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Chat Message Input Bar */}
          <form
            onSubmit={handleSendText}
            className="p-2.5 bg-white border-t border-orange-100 flex items-center gap-2"
          >
            <button
              type="button"
              onClick={() => setShowStickerPicker(!showStickerPicker)}
              className="p-2 rounded-full text-gray-500 hover:text-[#D97706] hover:bg-orange-50 transition-colors"
              title={t('desi_stickers')}
            >
              <Smile className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={handleSendVoiceNote}
              className={`p-2 rounded-full transition-colors ${
                isRecordingAudio
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'text-gray-500 hover:text-[#D97706] hover:bg-orange-50'
              }`}
              title="Send Voice Note"
            >
              <Mic className="w-5 h-5" />
            </button>

            <input
              type="text"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              placeholder={isRecordingAudio ? 'Recording Desi Voice Note...' : t('send_message')}
              disabled={isRecordingAudio}
              className="flex-1 bg-[#FFF9F2] border border-orange-200/80 rounded-full px-4 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />

            <button
              type="submit"
              disabled={!messageInput.trim()}
              className="p-2 rounded-full bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white disabled:opacity-40 hover:opacity-90 transition-opacity shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

