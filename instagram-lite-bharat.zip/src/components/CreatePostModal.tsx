import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Upload,
  Sparkles,
  Music,
  MapPin,
  Check,
  Wand2,
  RefreshCw,
} from 'lucide-react';
import {
  FILTER_PRESETS,
  DESI_STICKERS,
  AUDIO_TRACKS,
  INDIAN_LOCATIONS,
  PRESET_UPLOAD_PHOTOS,
} from '../data/initialData';
import { SpotifyMusicPickerModal } from './SpotifyMusicPickerModal';
import confetti from 'canvas-confetti';

export const CreatePostModal: React.FC = () => {
  const {
    currentUser,
    createNewPost,
    createNewStory,
    createNewReel,
    setActiveTab,
    t,
  } = useApp();

  const [mode, setMode] = useState<'post' | 'story' | 'reel'>('post');
  const [mediaUrl, setMediaUrl] = useState<string>(PRESET_UPLOAD_PHOTOS[0].url);
  const [selectedFilter, setSelectedFilter] = useState<string>('none');
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [warmth, setWarmth] = useState<number>(0);
  const [caption, setCaption] = useState<string>('');
  const [shayari, setShayari] = useState<string>('');
  const [hashtags, setHashtags] = useState<string>('#DesiVibes #ChaiPeCharcha #InstaBharat');
  const [selectedLocation, setSelectedLocation] = useState<string>(INDIAN_LOCATIONS[0]);
  const [selectedAudio, setSelectedAudio] = useState<any>(AUDIO_TRACKS[0]);
  const [isMusicPickerOpen, setIsMusicPickerOpen] = useState<boolean>(false);
  const [placedStickers, setPlacedStickers] = useState<{ id: string; emoji: string; x: number; y: number }[]>([]);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [aiVibe, setAiVibe] = useState<string>('chai');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setMediaUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddSticker = (emoji: string) => {
    const newSticker = {
      id: `st_${Date.now()}`,
      emoji,
      x: 35 + Math.random() * 30,
      y: 35 + Math.random() * 30,
    };
    setPlacedStickers((prev) => [...prev, newSticker]);
  };

  const handleGenerateAiCaption = async () => {
    try {
      setIsAiLoading(true);
      const res = await fetch('/api/ai/caption', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Photo of ${selectedLocation}`,
          vibe: aiVibe,
          location: selectedLocation,
          language: 'Hinglish with poetic desi touch',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.caption) setCaption(data.caption);
        if (data.shayari) setShayari(data.shayari);
        if (data.hashtags && Array.isArray(data.hashtags)) {
          setHashtags(data.hashtags.join(' '));
        }
        confetti({
          particleCount: 25,
          spread: 45,
          origin: { y: 0.7 },
          colors: ['#FF9933', '#EC4899', '#10B981'],
        });
      }
    } catch (err) {
      console.error('Failed to generate AI caption', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const computedFilterString = () => {
    let base = selectedFilter === 'none' ? '' : selectedFilter;
    const adjustments = `brightness(${brightness}%) contrast(${contrast}%) sepia(${warmth * 0.005})`;
    return base ? `${base} ${adjustments}` : adjustments;
  };

  const handlePublish = () => {
    const splitTags = hashtags
      .split(' ')
      .map((t) => t.trim())
      .filter((t) => t.startsWith('#') || t.length > 0)
      .map((t) => (t.startsWith('#') ? t : `#${t}`));

    if (mode === 'post') {
      createNewPost({
        userId: currentUser.id,
        username: currentUser.username,
        userAvatar: currentUser.avatar,
        location: selectedLocation,
        mediaUrl,
        mediaType: 'image',
        filter: computedFilterString(),
        caption: caption || 'Living the simple desi dream with kadak chai and smiles. ✨☕',
        shayari: shayari || undefined,
        hashtags: splitTags.length ? splitTags : ['#DesiVibes', '#BharatClicks'],
        audioTrack: selectedAudio,
        desiStickers: placedStickers.map((s) => ({
          id: s.id,
          type: 'emoji',
          emoji: s.emoji,
          x: s.x,
          y: s.y,
        })),
      });
    } else if (mode === 'story') {
      createNewStory({
        userId: currentUser.id,
        username: currentUser.username,
        userAvatar: currentUser.avatar,
        mediaUrl,
        mediaType: 'image',
        filter: computedFilterString(),
        caption: caption || 'Today in Bharat 🇮🇳',
        sticker: placedStickers[0]?.emoji ? `Desi Swag ${placedStickers[0].emoji}` : 'Chai & Chill ☕',
        audioTrack: `${selectedAudio.title} • ${selectedAudio.artist}`,
      });
      setActiveTab('feed');
    } else if (mode === 'reel') {
      createNewReel({
        userId: currentUser.id,
        username: currentUser.username,
        userAvatar: currentUser.avatar,
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-playing-the-tabla-drums-41586-large.mp4',
        thumbnailUrl: mediaUrl,
        caption: caption || 'Desi rhythm & vibes! 🥁✨ Drop a comment if you felt the rhythm!',
        audioTrack: {
          title: selectedAudio.title,
          artist: selectedAudio.artist,
        },
        tags: splitTags.length ? splitTags : ['#DesiReels', '#BharatMusic'],
      });
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto pb-24 px-2 sm:px-0">
      <div className="bg-white border border-orange-100 rounded-2xl shadow-xl overflow-hidden">
        {/* Header & Mode Switcher */}
        <div className="p-3.5 border-b border-orange-100 flex items-center justify-between bg-[#FFFAF5]">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-gray-900">
              Desi Studio • Naya Post
            </span>
            <span className="text-[10px] uppercase px-2.5 py-0.5 rounded-full bg-orange-100/80 text-[#D97706] font-bold border border-orange-200/80">
              Bharat Creator
            </span>
          </div>

          <div className="flex items-center bg-orange-50/80 p-1 rounded-xl border border-orange-100">
            <button
              onClick={() => setMode('post')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                mode === 'post'
                  ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Post
            </button>
            <button
              onClick={() => setMode('story')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                mode === 'story'
                  ? 'bg-rose-500 text-white shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Story
            </button>
            <button
              onClick={() => setMode('reel')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                mode === 'reel'
                  ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Reel
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
          {/* Left Column: Live Preview & Canvas Adjustments */}
          <div className="space-y-3">
            {/* Live Filter Image Canvas */}
            <div className="relative w-full aspect-square bg-gray-100 rounded-xl overflow-hidden border border-orange-100 shadow-inner flex items-center justify-center">
              <img
                src={mediaUrl}
                alt="Creation Preview"
                className="w-full h-full object-cover transition-all"
                style={{ filter: computedFilterString() }}
              />

              {/* Placed Desi Stickers */}
              {placedStickers.map((st) => (
                <div
                  key={st.id}
                  className="absolute text-4xl drop-shadow-xl select-none cursor-pointer"
                  style={{ left: `${st.x}%`, top: `${st.y}%` }}
                  onClick={() =>
                    setPlacedStickers((prev) => prev.filter((item) => item.id !== st.id))
                  }
                  title="Click to remove sticker"
                >
                  {st.emoji}
                </div>
              ))}

              {/* Media Tag Pill */}
              <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-xs border border-orange-200/80 text-[10px] text-gray-800 font-bold flex items-center gap-1.5 shadow-2xs">
                <Music className="w-3 h-3 text-[#FF9933]" />
                <span className="truncate max-w-[140px]">{selectedAudio.title}</span>
              </div>
            </div>

            {/* Photo Selection / Preset Bank */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-gray-600">
                <span className="font-bold text-gray-800">Choose Desi Visual:</span>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="text-[#D97706] hover:underline flex items-center gap-1 font-bold"
                >
                  <Upload className="w-3 h-3" /> Upload Custom Photo
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>

              {/* Presets Row */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {PRESET_UPLOAD_PHOTOS.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setMediaUrl(p.url);
                      setSelectedLocation(p.location);
                      setAiVibe(p.vibe);
                    }}
                    className={`relative flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden border-2 transition-all ${
                      mediaUrl === p.url
                        ? 'border-[#FF9933] scale-105 shadow-xs'
                        : 'border-orange-100 opacity-80 hover:opacity-100'
                    }`}
                  >
                    <img src={p.url} alt={p.name} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Indian Cultural Photo Filters */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-gray-800">
                Desi Filters (रंग और आभा):
              </span>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {FILTER_PRESETS.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSelectedFilter(f.cssFilter)}
                    className={`flex-shrink-0 px-2.5 py-1.5 rounded-xl border text-center transition-all ${
                      selectedFilter === f.cssFilter
                        ? 'bg-orange-100 border-[#FF9933] text-[#D97706] font-bold shadow-2xs'
                        : 'bg-white border-orange-100 text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <p className="text-[11px] whitespace-nowrap">{f.name}</p>
                    <p className="text-[9px] text-[#D97706]/80 font-serif">{f.desiName}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Desi Sticker Badges */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-gray-800">
                Add Desi Stickers (Tap to add):
              </span>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {DESI_STICKERS.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => handleAddSticker(st.emoji)}
                    className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-orange-100 hover:border-orange-300 text-sm hover:scale-110 active:scale-95 transition-all shadow-2xs"
                    title={st.name}
                  >
                    {st.emoji}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: AI Caption Generator & Details */}
          <div className="space-y-3.5 flex flex-col justify-between">
            <div className="space-y-3">
              {/* ✨ AI Desi Caption Generator Card */}
              <div className="p-3 rounded-xl bg-[#FFFAF5] border border-orange-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-gray-900">
                    <Sparkles className="w-4 h-4 text-[#FF9933]" />
                    <span>Gemini AI Desi Caption & Shayari</span>
                  </div>

                  <select
                    value={aiVibe}
                    onChange={(e) => setAiVibe(e.target.value)}
                    className="bg-white border border-orange-200/80 rounded-lg text-[11px] text-gray-800 px-2 py-1 focus:outline-none"
                  >
                    <option value="chai">☕ Chai & Sukoon</option>
                    <option value="bollywood">🎬 Bollywood Masala</option>
                    <option value="festive">🪔 Shaadi / Festive</option>
                    <option value="travel">🏔️ Desi Wanderlust</option>
                    <option value="sarcastic">😎 Bindaas Swag</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateAiCaption}
                  disabled={isAiLoading}
                  className="w-full py-1.5 rounded-lg bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white font-bold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-opacity shadow-xs disabled:opacity-50"
                >
                  {isAiLoading ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Wand2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isAiLoading ? 'Crafting Desi Magic...' : '✨ Generate Desi AI Caption'}</span>
                </button>
              </div>

              {/* Caption Input */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-800">
                  Caption (Hinglish/English):
                </label>
                <textarea
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="Ek cup kadak chai aur doston ki baatein... ☕"
                  rows={2}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl p-2.5 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
                />
              </div>

              {/* Optional Shayari Couplet */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-800 flex items-center gap-1">
                  <span>Poetic Desi Shayari (Sher 🪔):</span>
                </label>
                <input
                  type="text"
                  value={shayari}
                  onChange={(e) => setShayari(e.target.value)}
                  placeholder="Zindagi ek haseen safar hai, bas jeene ka andaaz aana chahiye."
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl p-2 text-xs text-orange-950 italic font-serif placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
                />
              </div>

              {/* Hashtags */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-800">
                  Indian Trending Hashtags:
                </label>
                <input
                  type="text"
                  value={hashtags}
                  onChange={(e) => setHashtags(e.target.value)}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl p-2 text-xs text-[#D97706] font-semibold placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
                />
              </div>

              {/* Location Selector */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-800 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-rose-500" />
                  <span>Location Tag:</span>
                </label>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl p-2 text-xs text-gray-900 focus:outline-none focus:border-[#FF9933]"
                >
                  {INDIAN_LOCATIONS.map((loc, idx) => (
                    <option key={idx} value={loc}>
                      📍 {loc}
                    </option>
                  ))}
                </select>
              </div>

              {/* Audio Track Selector & Spotify Integration */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-gray-800 flex items-center gap-1">
                    <Music className="w-3 h-3 text-[#1DB954]" />
                    <span>Song Soundtrack (Spotify Bharat):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsMusicPickerOpen(true)}
                    className="text-[11px] text-[#15803D] hover:underline font-bold flex items-center gap-1"
                  >
                    <span>Browse Spotify Songs 🎶</span>
                  </button>
                </div>

                <div
                  onClick={() => setIsMusicPickerOpen(true)}
                  className="p-2.5 rounded-xl bg-orange-50/70 border border-orange-200/90 flex items-center justify-between cursor-pointer hover:bg-orange-100/70 transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-[#1DB954] text-white flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.061-.779-.179-.839-.539-.06-.421.18-.78.54-.84 4.56-1.021 8.52-.6 11.64 1.32.42.18.48.66.241 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
                      </svg>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-gray-900 truncate">
                        {selectedAudio?.title || 'Attach Song from Spotify'}
                      </p>
                      <p className="text-[10px] text-gray-500 truncate">
                        {selectedAudio?.artist || 'Tap to choose music'}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white text-[#D97706] font-bold border border-orange-200">
                    Change ▾
                  </span>
                </div>
              </div>
            </div>

            {/* Publish Button */}
            <button
              onClick={handlePublish}
              className="w-full mt-3 py-3 rounded-xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white font-bold text-sm shadow-xs hover:opacity-95 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5 stroke-[2.5]" />
              <span>
                {mode === 'post'
                  ? 'Share Post to Bharat Feed 🇮🇳'
                  : mode === 'story'
                  ? 'Add to Kahaniyaan (Story) 🪔'
                  : 'Publish Jhalak (Reel) 🥁'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Spotify & Indian Songs Picker Modal */}
      <SpotifyMusicPickerModal
        isOpen={isMusicPickerOpen}
        onClose={() => setIsMusicPickerOpen(false)}
        onSelectTrack={(track) => {
          setSelectedAudio(track);
        }}
        selectedTrackId={selectedAudio?.id}
      />
    </div>
  );
};

