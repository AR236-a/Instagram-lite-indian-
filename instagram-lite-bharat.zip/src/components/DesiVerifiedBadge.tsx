import React, { useState } from 'react';

interface DesiVerifiedBadgeProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
  className?: string;
  tooltipText?: string;
}

export const DesiVerifiedBadge: React.FC<DesiVerifiedBadgeProps> = ({
  size = 'md',
  showLabel = false,
  className = '',
  tooltipText = 'Pramaanit Bharat Creator 🪷 (Verified Desi Voice)',
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  const sizeMap = {
    xs: {
      svg: 'w-3.5 h-3.5',
      pill: 'text-[9px] px-1.5 py-0.5',
    },
    sm: {
      svg: 'w-4 h-4',
      pill: 'text-[10px] px-2 py-0.5',
    },
    md: {
      svg: 'w-[18px] h-[18px]',
      pill: 'text-xs px-2.5 py-0.5',
    },
    lg: {
      svg: 'w-6 h-6',
      pill: 'text-xs px-3 py-1',
    },
    xl: {
      svg: 'w-7 h-7',
      pill: 'text-sm px-3.5 py-1',
    },
  };

  const selectedSize = sizeMap[size] || sizeMap.md;

  return (
    <span
      className={`relative inline-flex items-center gap-1 align-middle select-none group cursor-pointer ${className}`}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
      onClick={(e) => {
        e.stopPropagation();
        setShowTooltip(!showTooltip);
      }}
      title={tooltipText}
    >
      {/* 
        Custom Indian Cultural Verified Badge:
        Ornate 8-Petal Kamal (Lotus) & Ashoka Chakra Motif with Saffron-Gold Gradient & Radial Sheen
      */}
      <svg
        viewBox="0 0 24 24"
        className={`${selectedSize.svg} flex-shrink-0 drop-shadow-xs transition-transform duration-200 group-hover:scale-110`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="desiSaffronGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF9933" />
            <stop offset="50%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="desiInnerChakraGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#FEF3C7" />
          </linearGradient>
          <filter id="desiBadgeGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="1" stdDeviation="1" floodColor="#D97706" floodOpacity="0.35" />
          </filter>
        </defs>

        {/* 8-Petal Scalloped Lotus Mandala Base */}
        <path
          d="M12 1.5 
             C13.5 3 14.5 3.5 16.5 2.8 
             C18.2 2.2 19.5 3.2 19.8 5 
             C20.1 6.8 21.2 7.8 22.8 8.8 
             C24.1 9.7 24.3 11.5 23.3 12.8 
             C22.2 14.1 22.2 15.5 23.1 17 
             C23.9 18.4 23 20.1 21.3 20.5 
             C19.5 21 18.5 22 18 23.8 
             C17.5 25.3 15.6 25.8 14.2 24.8 
             C12.8 23.9 11.2 23.9 9.8 24.8 
             C8.4 25.8 6.5 25.3 6 23.8 
             C5.5 22 4.5 21 2.7 20.5 
             C1 20.1 0.1 18.4 0.9 17 
             C1.8 15.5 1.8 14.1 0.7 12.8 
             C-0.3 11.5 -0.1 9.7 1.2 8.8 
             C2.8 7.8 3.9 6.8 4.2 5 
             C4.5 3.2 5.8 2.2 7.5 2.8 
             C9.5 3.5 10.5 3 12 1.5 Z"
          fill="url(#desiSaffronGoldGrad)"
          stroke="#B45309"
          strokeWidth="0.75"
          filter="url(#desiBadgeGlow)"
        />

        {/* Inner Ornamental Sacred Mandala Ring */}
        <circle cx="12" cy="12" r="8.2" stroke="#FFF7ED" strokeWidth="0.8" strokeDasharray="1.5 1.2" opacity="0.85" />

        {/* Subtle Sunray / Ashoka spokes motif */}
        <g stroke="#FFF7ED" strokeWidth="0.6" opacity="0.65">
          <line x1="12" y1="4.5" x2="12" y2="6.2" />
          <line x1="12" y1="17.8" x2="12" y2="19.5" />
          <line x1="4.5" y1="12" x2="6.2" y2="12" />
          <line x1="17.8" y1="12" x2="19.5" y2="12" />
          <line x1="6.7" y1="6.7" x2="7.9" y2="7.9" />
          <line x1="16.1" y1="16.1" x2="17.3" y2="17.3" />
          <line x1="17.3" y1="6.7" x2="16.1" y2="7.9" />
          <line x1="7.9" y1="16.1" x2="6.7" y2="17.3" />
        </g>

        {/* Crisp Pure White Cultural Check Emblem */}
        <path
          d="M7.8 12.2 L10.5 14.9 L16.3 9.1"
          stroke="url(#desiInnerChakraGrad)"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      {/* Optional Label Tag */}
      {showLabel && (
        <span
          className={`inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-orange-100 to-amber-100 text-[#B45309] font-bold border border-orange-200 shadow-2xs ${selectedSize.pill}`}
        >
          <span>Pramaanit</span>
          <span className="text-[10px]">🪷</span>
        </span>
      )}

      {/* Tooltip on Hover */}
      {showTooltip && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 px-2.5 py-1 rounded-lg bg-gray-900 text-white text-[10px] font-medium whitespace-nowrap shadow-xl border border-orange-400/30 flex items-center gap-1 pointer-events-none animate-in fade-in zoom-in-95 duration-150">
          <span className="text-amber-400">🪷</span>
          <span>{tooltipText}</span>
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-gray-900" />
        </div>
      )}
    </span>
  );
};
