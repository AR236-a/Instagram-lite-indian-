import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Search, Flame, Sparkles, Heart, MessageCircle, MapPin, X } from 'lucide-react';
import { PostCard } from './PostCard';
import { Post } from '../types';

export const ExploreView: React.FC = () => {
  const { posts, t } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedPreviewPost, setSelectedPreviewPost] = useState<Post | null>(null);

  const categories = [
    { id: 'All', name: 'All Explore 🇮🇳' },
    { id: 'Chai', name: '☕ Chai Pe Charcha' },
    { id: 'Food', name: '🍛 Street Food Tapri' },
    { id: 'Fits', name: '🥻 Saree & Kurta Fits' },
    { id: 'Heritage', name: '🏰 Royal Heritage' },
    { id: 'Travel', name: '🧭 Desi Safar' },
    { id: 'Festive', name: '🪔 Utsav & Garba' },
  ];

  const filteredPosts = posts.filter((post) => {
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      post.username.toLowerCase().includes(query) ||
      post.caption.toLowerCase().includes(query) ||
      (post.location && post.location.toLowerCase().includes(query)) ||
      post.hashtags.some((h) => h.toLowerCase().includes(query));

    if (!matchesSearch) return false;

    if (activeCategory === 'All') return true;
    if (activeCategory === 'Chai') {
      return (
        post.caption.toLowerCase().includes('chai') ||
        post.hashtags.some((h) => h.toLowerCase().includes('chai'))
      );
    }
    if (activeCategory === 'Food') {
      return (
        post.caption.toLowerCase().includes('food') ||
        post.caption.toLowerCase().includes('golgappe') ||
        post.caption.toLowerCase().includes('samosa')
      );
    }
    if (activeCategory === 'Fits') {
      return (
        post.caption.toLowerCase().includes('saree') ||
        post.caption.toLowerCase().includes('fashion') ||
        post.caption.toLowerCase().includes('handloom')
      );
    }
    if (activeCategory === 'Heritage') {
      return (
        post.caption.toLowerCase().includes('fort') ||
        post.caption.toLowerCase().includes('palace') ||
        post.caption.toLowerCase().includes('heritage')
      );
    }
    if (activeCategory === 'Travel') {
      return (
        post.caption.toLowerCase().includes('travel') ||
        post.caption.toLowerCase().includes('mountain') ||
        post.caption.toLowerCase().includes('lake')
      );
    }
    if (activeCategory === 'Festive') {
      return (
        post.caption.toLowerCase().includes('aarti') ||
        post.caption.toLowerCase().includes('festival') ||
        post.caption.toLowerCase().includes('garba')
      );
    }
    return true;
  });

  return (
    <div className="w-full max-w-xl mx-auto pb-20 px-2 sm:px-0">
      {/* Search Input Bar */}
      <div className="relative mb-3 sticky top-14 z-30 pt-1">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search_placeholder')}
            className="w-full bg-white/95 border border-orange-200/80 rounded-2xl pl-10 pr-9 py-2.5 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933] backdrop-blur-md shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2.5 mb-3">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                : 'bg-white text-gray-700 border border-orange-100 hover:bg-orange-50'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Grid of Explore Media */}
      {filteredPosts.length === 0 ? (
        <div className="py-16 text-center text-gray-500 text-xs bg-white rounded-2xl border border-orange-100 p-8">
          <Sparkles className="w-8 h-8 mx-auto text-[#FF9933] mb-2" />
          <p>Koi post nahi mili. Try searching for "Chai", "Jaipur", "Saree" or "Dilli"!</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2 rounded-2xl overflow-hidden">
          {filteredPosts.map((post, idx) => {
            const isLarge = idx % 5 === 0;
            return (
              <div
                key={post.id}
                onClick={() => setSelectedPreviewPost(post)}
                className={`relative group cursor-pointer overflow-hidden bg-gray-100 rounded-xl aspect-square border border-orange-100/50 shadow-2xs ${
                  isLarge ? 'col-span-2 row-span-2' : ''
                }`}
              >
                <img
                  src={post.mediaUrl}
                  alt={post.caption}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  style={{ filter: post.filter || 'none' }}
                />

                {/* Hover Overlay with Likes & Comments */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white font-bold text-xs backdrop-blur-2xs">
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4 fill-white" />
                    <span>{post.likesCount}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>{post.comments.length}</span>
                  </div>
                </div>

                {/* Location Badge on Card */}
                {post.location && (
                  <div className="absolute bottom-1.5 left-1.5 px-2 py-0.5 rounded-full bg-white/90 backdrop-blur-xs text-[9px] text-[#D97706] font-bold truncate max-w-[85%] flex items-center gap-1 border border-orange-100">
                    <MapPin className="w-2.5 h-2.5 text-rose-500" />
                    <span className="truncate">{post.location.split(',')[0]}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Selected Post Preview Modal */}
      {selectedPreviewPost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white border border-orange-100 shadow-2xl">
            <button
              onClick={() => setSelectedPreviewPost(null)}
              className="absolute top-3 right-3 z-30 p-1.5 rounded-full bg-white/90 text-gray-700 hover:bg-orange-50 transition-colors border border-orange-200"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="pt-2">
              <PostCard post={selectedPreviewPost} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

