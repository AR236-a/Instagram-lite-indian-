import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Grid,
  Bookmark,
  Clapperboard,
  MapPin,
  Users,
  Edit3,
  X,
  Share2,
  Plus,
  Phone,
  Sparkles,
} from 'lucide-react';
import { User, Post, Reel, Highlight } from '../types';
import { PostCard } from './PostCard';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';
import { AddHighlightModal } from './AddHighlightModal';
import confetti from 'canvas-confetti';

export const ProfileView: React.FC = () => {
  const {
    currentUser,
    users,
    posts,
    reels,
    savedPostIds,
    toggleFollowUser,
    switchUser,
    updateProfile,
    setSelectedHighlight,
    setFollowersModalState,
    setShowContactLogin,
    t,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'grid' | 'reels' | 'saved'>('grid');
  const [selectedUser, setSelectedUser] = useState<User>(currentUser);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddHighlightOpen, setIsAddHighlightOpen] = useState(false);
  const [previewPost, setPreviewPost] = useState<Post | null>(null);

  // Edit form state
  const [editName, setEditName] = useState(currentUser.name);
  const [editBio, setEditBio] = useState(currentUser.bio);
  const [editLocation, setEditLocation] = useState(currentUser.location);
  const [editAvatar, setEditAvatar] = useState(currentUser.avatar);
  const [editBadge, setEditBadge] = useState(currentUser.badge || 'Chai Lover ☕');

  const isSelf = selectedUser.id === currentUser.id;

  // Filter posts and reels for the selected user
  const userPosts = posts.filter((p) => p.userId === selectedUser.id);
  const userReels = reels.filter((r) => r.userId === selectedUser.id);
  const savedPosts = posts.filter((p) => savedPostIds.includes(p.id));

  // Current user's highlights or fallback
  const userHighlights: Highlight[] =
    (isSelf ? currentUser.highlights : selectedUser.highlights) || [
      {
        id: 'h1',
        title: 'Chai Trails ☕',
        icon: '☕',
        cover: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&auto=format&fit=crop&q=80',
        stories: [],
      },
      {
        id: 'h2',
        title: 'Festive Fits 🥻',
        icon: '🥻',
        cover: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=400&auto=format&fit=crop&q=80',
        stories: [],
      },
      {
        id: 'h3',
        title: 'Desi Safar ✈️',
        icon: '🏔️',
        cover: 'https://images.unsplash.com/photo-1506197603052-3cc9c3a201bd?w=400&auto=format&fit=crop&q=80',
        stories: [],
      },
      {
        id: 'h4',
        title: 'Khana Peena 🍛',
        icon: '🍛',
        cover: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&auto=format&fit=crop&q=80',
        stories: [],
      },
    ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(editName, editBio, editLocation, editAvatar, editBadge);
    setSelectedUser((prev) => ({
      ...prev,
      name: editName,
      bio: editBio,
      location: editLocation,
      avatar: editAvatar,
      badge: editBadge,
    }));
    setIsEditModalOpen(false);
    confetti({
      particleCount: 25,
      spread: 40,
      colors: ['#FF9933', '#EC4899'],
    });
  };

  const handleOpenFollowers = (type: 'followers' | 'following' | 'contacts') => {
    setFollowersModalState({
      isOpen: true,
      type,
      targetUser: selectedUser,
    });
  };

  return (
    <div className="w-full max-w-xl mx-auto pb-24 px-2 sm:px-0">
      {/* Account Switcher Banner */}
      <div className="mb-3 p-2.5 bg-white border border-orange-100 rounded-2xl flex items-center justify-between overflow-x-auto no-scrollbar shadow-xs">
        <div className="flex items-center gap-1.5 flex-shrink-0 mr-2 text-[11px] font-bold text-[#D97706]">
          <Users className="w-3.5 h-3.5" />
          <span>Switch Profile:</span>
        </div>
        <div className="flex items-center gap-2">
          {users.map((u) => (
            <button
              key={u.id}
              onClick={() => {
                switchUser(u.id);
                setSelectedUser(u);
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedUser.id === u.id
                  ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                  : 'bg-orange-50/60 text-gray-700 border border-orange-100 hover:bg-orange-100/60'
              }`}
            >
              <img src={u.avatar} alt={u.name} className="w-4 h-4 rounded-full object-cover border border-white" />
              <span>@{u.username}</span>
              {u.isVerified && <DesiVerifiedBadge size="xs" />}
            </button>
          ))}
        </div>
      </div>

      {/* Main Profile Header Card */}
      <div className="bg-white border border-orange-100 rounded-2xl p-4 sm:p-5 mb-4 shadow-xs">
        <div className="flex items-center gap-4 sm:gap-6">
          {/* Avatar with Indian Lotus Glow Ring */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full p-[3px] bg-gradient-to-tr from-[#FF9933] via-amber-400 to-[#138808] shadow-md flex-shrink-0">
            <img
              src={selectedUser.avatar}
              alt={selectedUser.name}
              className="w-full h-full rounded-full object-cover border-2 border-white"
            />
          </div>

          {/* Stats & Actions */}
          <div className="flex-1 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-base sm:text-lg font-bold text-gray-900 leading-tight">
                    {selectedUser.name}
                  </h1>
                  {selectedUser.isVerified && <DesiVerifiedBadge size="sm" />}
                </div>
                <p className="text-xs text-[#D97706] font-semibold">
                  @{selectedUser.username}
                </p>
              </div>

              {/* Cultural Badge */}
              {selectedUser.badge && (
                <span className="px-2.5 py-0.5 rounded-full bg-orange-100/80 border border-orange-200/80 text-[#D97706] text-[10px] font-bold">
                  {selectedUser.badge}
                </span>
              )}
            </div>

            {/* Counters (Clickable for Followers/Following Modal) */}
            <div className="flex items-center justify-between text-center pt-1 border-t border-orange-50">
              <div>
                <span className="text-sm font-bold text-gray-900 block">
                  {userPosts.length}
                </span>
                <span className="text-[10px] text-gray-400 font-medium">Posts</span>
              </div>
              <div
                onClick={() => handleOpenFollowers('followers')}
                className="cursor-pointer hover:opacity-80 transition-opacity"
              >
                <span className="text-sm font-bold text-gray-900 block">
                  {selectedUser.followersCount.toLocaleString()}
                </span>
                <span className="text-[10px] text-[#D97706] font-bold hover:underline">
                  Followers
                </span>
              </div>
              <div
                onClick={() => handleOpenFollowers('following')}
                className="cursor-pointer hover:opacity-80 transition-opacity"
              >
                <span className="text-sm font-bold text-gray-900 block">
                  {selectedUser.followingCount}
                </span>
                <span className="text-[10px] text-[#D97706] font-bold hover:underline">
                  Following
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bio & Location & Contact Sync */}
        <div className="mt-3.5 space-y-1 text-xs">
          <div className="flex items-center justify-between text-gray-500 font-medium">
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>{selectedUser.location}</span>
            </div>
            {isSelf && (
              <button
                onClick={() => setShowContactLogin(true)}
                className="flex items-center gap-1 text-[10px] font-bold text-[#D97706] bg-orange-50 px-2 py-0.5 rounded-full border border-orange-200 hover:bg-orange-100"
              >
                <Phone className="w-2.5 h-2.5" />
                <span>Contact Login (+91)</span>
              </button>
            )}
          </div>
          <p className="text-gray-700 leading-relaxed">{selectedUser.bio}</p>
        </div>

        {/* Profile Action Buttons */}
        <div className="mt-4 flex items-center gap-2">
          {isSelf ? (
            <>
              <button
                onClick={() => {
                  setEditName(currentUser.name);
                  setEditBio(currentUser.bio);
                  setEditLocation(currentUser.location);
                  setEditAvatar(currentUser.avatar);
                  setEditBadge(currentUser.badge || 'Chai Lover ☕');
                  setIsEditModalOpen(true);
                }}
                className="flex-1 py-2 rounded-xl bg-orange-50 hover:bg-orange-100/80 text-gray-800 text-xs font-bold border border-orange-200/80 flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
              >
                <Edit3 className="w-3.5 h-3.5 text-[#D97706]" />
                <span>{t('edit_profile')}</span>
              </button>
              <button
                onClick={() => handleOpenFollowers('contacts')}
                className="py-2 px-3 rounded-xl bg-orange-50 hover:bg-orange-100/80 text-[#D97706] text-xs font-bold border border-orange-200/80 flex items-center justify-center gap-1 shadow-2xs"
                title="Phone Contacts Directory"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Contacts</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => toggleFollowUser(selectedUser.id)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all shadow-xs ${
                selectedUser.isFollowing
                  ? 'bg-orange-50 text-gray-800 border border-orange-200'
                  : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white'
              }`}
            >
              {selectedUser.isFollowing ? 'Following (Dost) ✓' : '+ Follow Karo'}
            </button>
          )}

          <button
            onClick={() => {
              confetti({ particleCount: 20, spread: 30 });
              navigator.clipboard?.writeText(window.location.href);
            }}
            className="p-2 rounded-xl bg-orange-50 hover:bg-orange-100/80 text-gray-700 border border-orange-200/80 shadow-2xs"
            title="Share Profile"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Story Highlights (Kahani Sangrah & Highlights Manager) */}
      <div className="mb-4 bg-white border border-orange-100 rounded-2xl p-3 shadow-xs">
        <div className="flex items-center justify-between px-1 mb-2.5">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-gray-800">
              Desi Story Highlights 🪔
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 text-[#D97706] font-bold">
              {userHighlights.length} Albums
            </span>
          </div>

          {isSelf && (
            <button
              onClick={() => setIsAddHighlightOpen(true)}
              className="text-[11px] font-bold text-[#D97706] hover:text-orange-700 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Add Highlight</span>
            </button>
          )}
        </div>

        {/* Highlights Horizontal Scroll Rail */}
        <div className="flex items-center gap-3.5 overflow-x-auto no-scrollbar py-1">
          {/* Add Highlight Button for current user */}
          {isSelf && (
            <div
              onClick={() => setIsAddHighlightOpen(true)}
              className="flex flex-col items-center flex-shrink-0 group cursor-pointer"
            >
              <div className="w-14 h-14 rounded-full border-2 border-dashed border-[#FF9933] flex items-center justify-center bg-orange-50/60 group-hover:bg-orange-100 transition-colors">
                <Plus className="w-5 h-5 text-[#D97706]" />
              </div>
              <span className="text-[10px] text-gray-700 font-bold mt-1">New Highlight</span>
            </div>
          )}

          {/* User Highlights List */}
          {userHighlights.map((h) => (
            <div
              key={h.id}
              onClick={() => setSelectedHighlight(h)}
              className="flex flex-col items-center flex-shrink-0 group cursor-pointer"
            >
              <div className="relative w-14 h-14 rounded-full p-[2px] bg-gradient-to-tr from-[#FF9933] via-amber-400 to-[#138808] group-hover:scale-105 transition-all shadow-xs">
                <img
                  src={h.cover}
                  alt={h.title}
                  className="w-full h-full rounded-full object-cover border border-white"
                />
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white border border-orange-200 flex items-center justify-center text-[10px] shadow-2xs">
                  {h.icon || '🪔'}
                </div>
              </div>
              <span className="text-[10px] text-gray-800 font-bold mt-1 truncate max-w-[70px]">
                {h.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Profile Segmented Tabs */}
      <div className="flex items-center border-b border-orange-100 mb-3 bg-white rounded-t-xl px-2">
        <button
          onClick={() => setActiveTab('grid')}
          className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'grid'
              ? 'border-[#FF9933] text-[#D97706]'
              : 'border-transparent text-gray-400 hover:text-gray-700'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Posts ({userPosts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reels')}
          className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'reels'
              ? 'border-rose-500 text-rose-500'
              : 'border-transparent text-gray-400 hover:text-gray-700'
          }`}
        >
          <Clapperboard className="w-4 h-4" />
          <span>Reels ({userReels.length})</span>
        </button>

        {isSelf && (
          <button
            onClick={() => setActiveTab('saved')}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'saved'
                ? 'border-[#FF9933] text-[#D97706]'
                : 'border-transparent text-gray-400 hover:text-gray-700'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({savedPosts.length})</span>
          </button>
        )}
      </div>

      {/* Media Grid View */}
      {activeTab === 'grid' && (
        <div className="grid grid-cols-3 gap-2 rounded-xl overflow-hidden">
          {userPosts.length === 0 ? (
            <div className="col-span-3 py-12 text-center text-gray-400 text-xs bg-white rounded-xl border border-orange-100 p-6">
              No posts uploaded yet. Share your first desi moment! ☕
            </div>
          ) : (
            userPosts.map((post) => (
              <div
                key={post.id}
                onClick={() => setPreviewPost(post)}
                className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden cursor-pointer group border border-orange-100 shadow-2xs"
              >
                <img
                  src={post.mediaUrl}
                  alt={post.caption}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  style={{ filter: post.filter || 'none' }}
                />
                {post.isRepost && (
                  <div className="absolute top-1.5 left-1.5 bg-black/60 backdrop-blur-xs text-white p-1 rounded-md text-[10px]">
                    🔁
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'reels' && (
        <div className="grid grid-cols-3 gap-2 rounded-xl overflow-hidden">
          {userReels.length === 0 ? (
            <div className="col-span-3 py-12 text-center text-gray-400 text-xs bg-white rounded-xl border border-orange-100 p-6">
              No reels recorded yet. Capture a quick Jhalak! 🥁
            </div>
          ) : (
            userReels.map((reel) => (
              <div
                key={reel.id}
                className="relative aspect-[9/16] bg-gray-100 rounded-xl overflow-hidden cursor-pointer group border border-orange-100 shadow-2xs"
              >
                <img
                  src={reel.thumbnailUrl}
                  alt={reel.caption}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 left-2 flex items-center gap-1 text-[10px] text-white font-bold bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-xs">
                  <Clapperboard className="w-3 h-3 text-[#FF9933]" />
                  <span>{reel.likesCount}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'saved' && (
        <div className="grid grid-cols-3 gap-2 rounded-xl overflow-hidden">
          {savedPosts.length === 0 ? (
            <div className="col-span-3 py-12 text-center text-gray-400 text-xs bg-white rounded-xl border border-orange-100 p-6">
              No saved posts in your Khazana yet.
            </div>
          ) : (
            savedPosts.map((post) => (
              <div
                key={post.id}
                onClick={() => setPreviewPost(post)}
                className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden cursor-pointer group border border-orange-100 shadow-2xs"
              >
                <img
                  src={post.mediaUrl}
                  alt={post.caption}
                  className="w-full h-full object-cover"
                  style={{ filter: post.filter || 'none' }}
                />
              </div>
            ))
          )}
        </div>
      )}

      {/* Post Preview Modal */}
      {previewPost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-2xl bg-white border border-orange-100 shadow-2xl">
            <button
              onClick={() => setPreviewPost(null)}
              className="absolute top-3 right-3 z-30 p-1.5 rounded-full bg-white/90 text-gray-700 hover:bg-orange-50 border border-orange-200"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="pt-2">
              <PostCard post={previewPost} />
            </div>
          </div>
        </div>
      )}

      {/* Add Highlight Modal */}
      <AddHighlightModal
        isOpen={isAddHighlightOpen}
        onClose={() => setIsAddHighlightOpen(false)}
      />

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="w-full max-w-md bg-white border border-orange-100 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-orange-100">
              <h2 className="text-sm font-bold text-gray-900">Edit Profile 🪔</h2>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="text-gray-400 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="text-xs text-gray-600 font-bold block mb-1">Full Name:</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:border-[#FF9933]"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 font-bold block mb-1">Desi Bio:</label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={2}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl p-2.5 text-xs text-gray-900 focus:outline-none focus:border-[#FF9933]"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 font-bold block mb-1">City / Location:</label>
                <input
                  type="text"
                  value={editLocation}
                  onChange={(e) => setEditLocation(e.target.value)}
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:border-[#FF9933]"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 font-bold block mb-1">Cultural Badge Tag:</label>
                <input
                  type="text"
                  value={editBadge}
                  onChange={(e) => setEditBadge(e.target.value)}
                  placeholder="e.g. Chai Addict ☕, Bollywood Buff 🎬"
                  className="w-full bg-[#FFF9F2] border border-orange-200/80 rounded-xl px-3 py-2 text-xs text-[#D97706] font-bold focus:outline-none focus:border-[#FF9933]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-500 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white font-bold text-xs shadow-xs hover:opacity-90 transition-opacity"
                >
                  Save Profile Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
