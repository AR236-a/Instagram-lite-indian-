import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Sparkles, Image, Check, Plus } from 'lucide-react';
import { PRESET_UPLOAD_PHOTOS } from '../data/initialData';

interface AddHighlightModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddHighlightModal: React.FC<AddHighlightModalProps> = ({ isOpen, onClose }) => {
  const { addStoryHighlight, stories, currentUser } = useApp();

  const [title, setTitle] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('🪔');
  const [selectedCover, setSelectedCover] = useState(
    stories[0]?.mediaUrl || PRESET_UPLOAD_PHOTOS[0]?.url || 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=500&auto=format&fit=crop&q=80'
  );
  const [customCoverUrl, setCustomCoverUrl] = useState('');

  if (!isOpen) return null;

  const DESI_ICONS = ['🪔', '☕', '🏰', '✨', '🦚', '🥘', '🏔️', '📸', '🥻', '🚂', '🎶', '🏖️', '🌸', '🇮🇳', '🕺'];

  const availablePhotos = [
    ...stories.map((s) => s.mediaUrl),
    ...PRESET_UPLOAD_PHOTOS.map((p) => p.url),
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const finalCover = customCoverUrl.trim() || selectedCover;

    addStoryHighlight({
      title: `${title.trim()} ${selectedIcon}`,
      cover: finalCover,
      icon: selectedIcon,
      stories: [
        {
          id: `hl_s_${Date.now()}`,
          userId: currentUser.id,
          username: currentUser.username,
          userAvatar: currentUser.avatar,
          mediaUrl: finalCover,
          mediaType: 'image',
          caption: `${title.trim()} highlights! ✨ Made with Desi Pyaar.`,
          sticker: `${title.trim()} ${selectedIcon}`,
          audioTrack: 'Kesariya • Arijit Singh',
          timestamp: 'Highlight',
          viewersCount: 1,
        },
      ],
    });

    setTitle('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-white border border-orange-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#FF9933]/10 via-[#F59E0B]/10 to-orange-50 border-b border-orange-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#FF9933] to-[#D97706] flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">New Story Highlight</h3>
              <p className="text-[11px] text-gray-500">Save your best memories to your Bharat Profile</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-orange-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Highlight Preview */}
          <div className="flex flex-col items-center justify-center py-2">
            <div className="relative w-20 h-20 rounded-full p-[2px] bg-gradient-to-tr from-[#FF9933] via-[#D97706] to-[#138808] shadow-md">
              <img
                src={customCoverUrl.trim() || selectedCover}
                alt="Highlight Cover"
                className="w-full h-full rounded-full object-cover border-2 border-white"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-white border border-orange-200 flex items-center justify-center text-xs shadow-xs">
                {selectedIcon}
              </div>
            </div>
            <p className="text-xs font-bold text-gray-800 mt-2">
              {title.trim() ? `${title.trim()} ${selectedIcon}` : `Highlight Name ${selectedIcon}`}
            </p>
          </div>

          {/* Title Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-800">Highlight Title (नाम)</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Diwali 2024, Chai Safar, Goa Trips..."
              required
              className="w-full bg-[#FFFAF5] border border-orange-200 rounded-2xl px-4 py-2.5 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />
          </div>

          {/* Select Desi Icon */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-800">Desi Emblem / Emoji</label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-[#FFFAF5] rounded-2xl border border-orange-100">
              {DESI_ICONS.map((icon) => (
                <button
                  type="button"
                  key={icon}
                  onClick={() => setSelectedIcon(icon)}
                  className={`w-8 h-8 rounded-xl flex items-center justify-center text-base transition-all ${
                    selectedIcon === icon
                      ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white scale-110 shadow-xs'
                      : 'hover:bg-orange-100'
                  }`}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Select Cover Image */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-800">Select Cover Photo</label>
            <div className="grid grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1">
              {availablePhotos.slice(0, 8).map((photo, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedCover(photo);
                    setCustomCoverUrl('');
                  }}
                  className={`relative aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                    selectedCover === photo && !customCoverUrl
                      ? 'border-[#FF9933] ring-2 ring-[#FF9933]/30 scale-95'
                      : 'border-transparent hover:opacity-90'
                  }`}
                >
                  <img src={photo} alt={`Option ${idx}`} className="w-full h-full object-cover" />
                  {selectedCover === photo && !customCoverUrl && (
                    <div className="absolute inset-0 bg-[#FF9933]/30 flex items-center justify-center text-white">
                      <Check className="w-4 h-4 stroke-[3]" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white text-xs font-bold shadow-md hover:opacity-95 transition-opacity"
          >
            Save Highlight to Profile 🪷
          </button>
        </form>
      </div>
    </div>
  );
};
