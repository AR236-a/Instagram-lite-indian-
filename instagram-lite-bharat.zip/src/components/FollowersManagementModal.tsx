import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { User, ContactItem } from '../types';
import { Search, X, UserPlus, UserCheck, Phone, Users, ShieldCheck, Heart } from 'lucide-react';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';
import { SAMPLE_CONTACTS } from './ContactLoginModal';
import confetti from 'canvas-confetti';

export const FollowersManagementModal: React.FC = () => {
  const {
    followersModalState,
    setFollowersModalState,
    users,
    currentUser,
    toggleFollowUser,
    appPermissions,
    setShowContactLogin,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'followers' | 'following' | 'contacts'>(
    followersModalState?.type || 'followers'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [contacts, setContacts] = useState<ContactItem[]>(SAMPLE_CONTACTS);

  useEffect(() => {
    if (followersModalState?.type) {
      setActiveTab(followersModalState.type);
    }
  }, [followersModalState?.type]);

  if (!followersModalState?.isOpen) return null;

  const targetUser = followersModalState.targetUser || currentUser;
  const isMe = targetUser.id === currentUser.id;

  // Filter users
  const followingUsers = users.filter((u) => u.id !== targetUser.id && u.isFollowing);
  const followerUsers = users.filter((u) => u.id !== targetUser.id);

  const displayedUsers = (activeTab === 'following' ? followingUsers : followerUsers).filter(
    (u) =>
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredContacts = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleContact = (c: ContactItem) => {
    if (c.userId) {
      toggleFollowUser(c.userId);
      setContacts((prev) =>
        prev.map((item) => (item.id === c.id ? { ...item, isFollowing: !item.isFollowing } : item))
      );
      confetti({
        particleCount: 20,
        spread: 40,
        colors: ['#FF9933', '#10B981'],
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-white border border-orange-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#FF9933]/10 via-[#F59E0B]/10 to-orange-50 border-b border-orange-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#FF9933] to-[#D97706] flex items-center justify-center text-white shadow-xs">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-gray-900">
                  {targetUser.name}'s Desi Circle
                </h3>
                <DesiVerifiedBadge size="xs" />
              </div>
              <p className="text-[11px] text-gray-500">
                @{targetUser.username} • {targetUser.followersCount} Followers
              </p>
            </div>
          </div>

          <button
            onClick={() => setFollowersModalState(null)}
            className="p-1.5 rounded-full hover:bg-orange-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 border-b border-orange-100 bg-[#FFFAF5] text-xs font-bold">
          <button
            onClick={() => setActiveTab('followers')}
            className={`py-3 text-center border-b-2 transition-all ${
              activeTab === 'followers'
                ? 'border-[#D97706] text-[#D97706] bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            Followers ({targetUser.followersCount})
          </button>
          <button
            onClick={() => setActiveTab('following')}
            className={`py-3 text-center border-b-2 transition-all ${
              activeTab === 'following'
                ? 'border-[#D97706] text-[#D97706] bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            Following ({targetUser.followingCount})
          </button>
          <button
            onClick={() => setActiveTab('contacts')}
            className={`py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1 ${
              activeTab === 'contacts'
                ? 'border-[#D97706] text-[#D97706] bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <span>Contacts 🇮🇳</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-orange-100 bg-white">
          <div className="relative">
            <Search className="w-4 h-4 text-[#FF9933] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                activeTab === 'contacts'
                  ? 'Search phonebook contacts...'
                  : 'Search by username or location...'
              }
              className="w-full bg-[#FFFAF5] border border-orange-200/80 rounded-2xl pl-10 pr-4 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto divide-y divide-orange-50 p-2">
          {activeTab === 'contacts' ? (
            <div className="space-y-2">
              <div className="p-2.5 rounded-2xl bg-orange-50/70 border border-orange-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-orange-950">
                  <Phone className="w-4 h-4 text-[#FF9933]" />
                  <span>Synced from Phone Directory (+91)</span>
                </div>
                <button
                  onClick={() => {
                    setFollowersModalState(null);
                    setShowContactLogin(true);
                  }}
                  className="text-[11px] font-bold text-[#D97706] hover:underline"
                >
                  Manage Permissions
                </button>
              </div>

              {filteredContacts.map((c) => (
                <div
                  key={c.id}
                  className={`p-2.5 rounded-2xl flex items-center justify-between gap-2 transition-colors ${
                    c.isOriginalContact
                      ? 'bg-amber-50/90 border border-amber-300 shadow-xs'
                      : 'hover:bg-orange-50/70 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="relative flex-shrink-0">
                      <img
                        src={c.avatar}
                        alt={c.name}
                        className="w-10 h-10 rounded-full object-cover border-2 border-orange-300"
                      />
                      {c.isOriginalContact && (
                        <span className="absolute -bottom-1 -right-1 text-[10px] bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white px-1 rounded-full font-bold shadow-xs">
                          ★
                        </span>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="text-xs font-bold text-gray-900 truncate">{c.name}</p>
                        <DesiVerifiedBadge size="xs" />
                        {c.isOriginalContact && (
                          <span className="px-1.5 py-0.5 rounded-md bg-orange-100 text-[#D97706] text-[9px] font-extrabold tracking-wide">
                            Original Contact
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-gray-600 truncate">
                        {c.phone} {c.email ? `• ${c.email}` : ''}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggleContact(c)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 flex-shrink-0 ${
                      c.isFollowing
                        ? 'bg-orange-100 text-[#D97706] border border-orange-200'
                        : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                    }`}
                  >
                    {c.isFollowing ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow Back</span>
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-1">
              {displayedUsers.length === 0 ? (
                <div className="py-10 text-center text-xs text-gray-400">
                  No users found matching "{searchQuery}"
                </div>
              ) : (
                displayedUsers.map((u) => (
                  <div
                    key={u.id}
                    className="p-2.5 rounded-2xl hover:bg-orange-50/70 flex items-center justify-between gap-2 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={u.avatar}
                        alt={u.name}
                        className="w-9 h-9 rounded-full object-cover border border-orange-200 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold text-gray-900 truncate">{u.name}</p>
                          {u.isVerified && <DesiVerifiedBadge size="xs" />}
                        </div>
                        <p className="text-[10px] text-gray-500 truncate">
                          @{u.username} • {u.location}
                        </p>
                      </div>
                    </div>

                    {u.id !== currentUser.id && (
                      <button
                        onClick={() => toggleFollowUser(u.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 flex-shrink-0 ${
                          u.isFollowing
                            ? 'bg-orange-100 text-[#D97706] border border-orange-200'
                            : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white shadow-xs'
                        }`}
                      >
                        {u.isFollowing ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>Following</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>Follow</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
