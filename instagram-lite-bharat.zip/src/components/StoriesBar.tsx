import React from 'react';
import { useApp } from '../context/AppContext';
import { Plus } from 'lucide-react';

interface StoriesBarProps {
  onAddStoryClick: () => void;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({ onAddStoryClick }) => {
  const { currentUser, stories, setSelectedStory, t } = useApp();

  const userStory = stories.find((s) => s.userId === currentUser.id);
  const otherStories = stories.filter((s) => s.userId !== currentUser.id);

  const handleStoryClick = (storyIndex: number, storyList = stories) => {
    setSelectedStory({
      stories: storyList,
      initialIndex: storyIndex,
    });
  };

  return (
    <div className="w-full bg-[#FFFAF5] border border-orange-100/90 rounded-2xl p-3.5 mb-4 shadow-sm overflow-hidden">
      <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-0.5">
        {/* Current User Story / Add Story */}
        <div className="flex flex-col items-center flex-shrink-0 cursor-pointer group">
          <div className="relative">
            <div
              onClick={() => {
                if (userStory) {
                  handleStoryClick(0, [userStory]);
                } else {
                  onAddStoryClick();
                }
              }}
              className={`w-16 h-16 rounded-full p-[2px] transition-transform group-hover:scale-105 ${
                userStory
                  ? 'bg-gradient-to-tr from-[#FF9933] via-[#D97706] to-[#138808]'
                  : 'bg-orange-200/80'
              }`}
            >
              <div className="w-full h-full bg-white rounded-full p-[2px]">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.username}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAddStoryClick();
              }}
              className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white flex items-center justify-center border-2 border-white shadow-sm group-hover:scale-110 transition-transform"
              title={t('add_story')}
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </button>
          </div>
          <span className="text-[11px] text-gray-700 font-medium mt-1.5 max-w-[68px] truncate">
            {t('your_story')}
          </span>
        </div>

        {/* Other Users' Stories */}
        {otherStories.map((story, idx) => (
          <div
            key={story.id}
            onClick={() => handleStoryClick(idx, otherStories)}
            className="flex flex-col items-center flex-shrink-0 cursor-pointer group"
          >
            <div
              className={`w-16 h-16 rounded-full p-[2px] transition-transform group-hover:scale-105 ${
                story.seen
                  ? 'bg-gray-200'
                  : 'bg-gradient-to-tr from-[#FF9933] via-[#EC4899] to-[#D97706]'
              }`}
            >
              <div className="w-full h-full bg-white rounded-full p-[2px]">
                <img
                  src={story.userAvatar}
                  alt={story.username}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
            <span className="text-[11px] text-gray-700 font-medium mt-1.5 max-w-[68px] truncate">
              {story.username.replace('@', '')}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

