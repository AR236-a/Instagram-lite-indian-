import React, { useState, useEffect } from 'react';
import { Post, Comment } from '../types';
import { useApp } from '../context/AppContext';
import { X, Heart, Trash2, Send, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CommentsModalProps {
  post: Post;
  isOpen: boolean;
  onClose: () => void;
}

export const CommentsModal: React.FC<CommentsModalProps> = ({ post, isOpen, onClose }) => {
  const { currentUser, addCommentToPost, deleteComment, t } = useApp();
  const [commentText, setCommentText] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([
    'Kya baat hai! Kadak photo boss 🔥',
    'Ekdum Bollywood hero entry! ✨',
    'Sundar aur shandaar! 👏',
    'Chai pe kab bula rahe ho? ☕',
  ]);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  useEffect(() => {
    const fetchAiComments = async () => {
      try {
        setIsGeneratingAi(true);
        const res = await fetch('/api/ai/suggest-comments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ postCaption: post.caption, authorName: post.username }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.suggestions && data.suggestions.length > 0) {
            setAiSuggestions(data.suggestions);
          }
        }
      } catch (e) {
        // Fallback already preset
      } finally {
        setIsGeneratingAi(false);
      }
    };

    if (isOpen) {
      fetchAiComments();
    }
  }, [isOpen, post.caption, post.username]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addCommentToPost(post.id, commentText);
    setCommentText('');
  };

  const handleQuickAdd = (text: string) => {
    addCommentToPost(post.id, text);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-lg bg-white border border-orange-100 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden"
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-orange-100 bg-[#FFFAF5] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-gray-900">
                Comments ({post.comments.length})
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-orange-100/70 text-[#D97706] border border-orange-200/80 font-bold">
                Desi Charcha ☕
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-gray-400 hover:text-gray-800 hover:bg-orange-100/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Comments List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 divide-y divide-orange-50">
            {/* Post Author Caption as first item */}
            <div className="flex items-start gap-3 pb-3">
              <img
                src={post.userAvatar}
                alt={post.username}
                className="w-8 h-8 rounded-full object-cover border border-orange-200 flex-shrink-0"
              />
              <div className="flex-1 text-xs">
                <p className="text-gray-800 leading-relaxed">
                  <span className="font-bold text-[#D97706] mr-1.5">{post.username}</span>
                  {post.caption}
                </p>
                {post.shayari && (
                  <p className="mt-1.5 text-[11px] text-orange-950 italic font-serif bg-orange-50 p-2 rounded-xl border border-orange-200/60">
                    "{post.shayari}"
                  </p>
                )}
                <span className="text-[10px] text-gray-400 mt-1 block font-medium">{post.timestamp}</span>
              </div>
            </div>

            {/* Existing Comments */}
            {post.comments.length === 0 ? (
              <div className="py-8 text-center text-gray-400 text-xs">
                Koi comment nahi hai abhi. Be the first to drop some desi love! 🪔
              </div>
            ) : (
              post.comments.map((comment) => (
                <div key={comment.id} className="flex items-start gap-3 pt-3">
                  <img
                    src={comment.userAvatar}
                    alt={comment.username}
                    className="w-7 h-7 rounded-full object-cover flex-shrink-0 border border-orange-100"
                  />
                  <div className="flex-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-900">{comment.username}</span>
                      {comment.userId === currentUser.id && (
                        <button
                          onClick={() => deleteComment(post.id, comment.id)}
                          className="text-gray-400 hover:text-red-500 p-1 transition-colors"
                          title="Delete comment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <p className="text-gray-700 mt-0.5 leading-relaxed">{comment.text}</p>
                    <div className="flex items-center gap-3 mt-1 text-[10px] text-gray-400">
                      <span>{comment.timestamp}</span>
                      <button className="hover:text-[#D97706] font-medium">Reply</button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick AI Desi Suggestion Pills */}
          <div className="px-4 py-2 bg-[#FFFAF5] border-t border-orange-100">
            <div className="flex items-center gap-1.5 mb-1.5 text-[10px] text-[#D97706] font-bold">
              <Sparkles className="w-3 h-3 text-[#FF9933]" />
              <span>Desi AI Quick Reactions:</span>
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {aiSuggestions.map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickAdd(sug)}
                  className="px-2.5 py-1 rounded-full bg-white hover:bg-orange-50 text-gray-800 text-[11px] font-medium whitespace-nowrap border border-orange-200/80 transition-all hover:border-orange-300 active:scale-95 shadow-2xs"
                >
                  {sug}
                </button>
              ))}
            </div>
          </div>

          {/* Add Comment Input */}
          <form onSubmit={handleSubmit} className="p-3 bg-white border-t border-orange-100 flex items-center gap-2">
            <img
              src={currentUser.avatar}
              alt={currentUser.username}
              className="w-7 h-7 rounded-full object-cover flex-shrink-0 border border-orange-200"
            />
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={t('add_comment')}
              className="flex-1 bg-[#FFF9F2] border border-orange-200/80 rounded-full px-3.5 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#FF9933]"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              className="p-2 rounded-full bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white disabled:opacity-40 hover:opacity-90 transition-opacity shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

