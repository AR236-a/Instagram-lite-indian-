import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Volume2,
  VolumeX,
  Heart,
  Send,
  ChevronLeft,
  ChevronRight,
  Music,
  Plus,
  Sparkles,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';

export const StoryViewer: React.FC = () => {
  const {
    selectedStory,
    setSelectedStory,
    markStorySeen,
    sendMessage,
    currentUser,
    users,
  } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showHeartAnim, setShowHeartAnim] = useState(false);

  // Sync index when selectedStory changes
  useEffect(() => {
    if (selectedStory) {
      setCurrentIndex(selectedStory.initialIndex || 0);
      setProgress(0);
    }
  }, [selectedStory]);

  const storiesCount = selectedStory?.stories?.length || 0;
  const activeStory = selectedStory?.stories?.[currentIndex];
  const storyDuration = 5000; // 5 seconds per story

  const storyAuthor = users.find((u) => u.id === activeStory?.userId);
  const isVerified = storyAuthor?.isVerified ?? true;

  useEffect(() => {
    if (activeStory) {
      markStorySeen(activeStory.id);
    }
    setProgress(0);
  }, [currentIndex, activeStory?.id]);

  useEffect(() => {
    if (!selectedStory || storiesCount === 0 || isPaused) return;

    const interval = 50;
    const step = (interval / storyDuration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < storiesCount - 1) {
            setCurrentIndex((idx) => idx + 1);
            return 0;
          } else {
            setSelectedStory(null);
            return 0;
          }
        }
        return prev + step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [selectedStory, currentIndex, isPaused, storiesCount, setSelectedStory]);

  const handleNextStory = () => {
    if (currentIndex < storiesCount - 1) {
      setCurrentIndex((prev) => prev + 1);
      setProgress(0);
    } else {
      setSelectedStory(null);
    }
  };

  const handlePrevStory = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setProgress(0);
    }
  };

  const handleQuickReaction = (emoji: string) => {
    if (!activeStory) return;
    setShowHeartAnim(true);
    confetti({
      particleCount: 30,
      spread: 50,
      origin: { y: 0.8 },
      colors: ['#EC4899', '#F59E0B', '#10B981'],
    });
    setTimeout(() => setShowHeartAnim(false), 1200);

    // Send as message in DM
    if (activeStory.userId !== currentUser.id) {
      const chatId = `chat_${activeStory.userId.replace('user_', '')}`;
      sendMessage(chatId, `Reacted ${emoji} to your story: "${activeStory.caption || 'Desi moment'}"`);
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeStory) return;

    const chatId = `chat_${activeStory.userId.replace('user_', '')}`;
    sendMessage(chatId, `Replying to story: "${replyText}"`);
    setReplyText('');
    confetti({
      particleCount: 20,
      spread: 40,
      origin: { y: 0.85 },
      colors: ['#F59E0B', '#EC4899'],
    });
  };

  if (!selectedStory || !activeStory || storiesCount === 0) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center">
        {/* Close Button */}
        <button
          onClick={() => setSelectedStory(null)}
          className="absolute top-4 right-4 z-50 p-2 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-white transition-colors shadow-lg"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Story Content Wrapper */}
        <div
          className="relative w-full max-w-md h-[90vh] max-h-[820px] bg-neutral-950 rounded-2xl overflow-hidden shadow-2xl flex flex-col border border-neutral-800"
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {/* Progress Bars */}
          <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1.5">
            {selectedStory.stories.map((s, idx) => (
              <div
                key={s.id}
                className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden"
              >
                <div
                  className="h-full bg-gradient-to-r from-[#FF9933] to-[#D97706] rounded-full transition-all duration-75"
                  style={{
                    width:
                      idx < currentIndex
                        ? '100%'
                        : idx === currentIndex
                        ? `${progress}%`
                        : '0%',
                  }}
                />
              </div>
            ))}
          </div>

          {/* Top User Header */}
          <div className="absolute top-6 left-3 right-3 z-30 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={activeStory.userAvatar}
                alt={activeStory.username}
                className="w-9 h-9 rounded-full object-cover border-2 border-[#FF9933]"
              />
              <div>
                <div className="flex items-center gap-1">
                  <span className="text-sm font-bold text-white tracking-tight drop-shadow-sm">
                    {activeStory.username}
                  </span>
                  {isVerified && <DesiVerifiedBadge size="xs" />}
                </div>
                <p className="text-[10px] text-orange-200/90 font-medium">
                  {activeStory.timestamp}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsMuted(!isMuted);
                }}
                className="p-1.5 rounded-full bg-black/40 text-white hover:bg-black/60 backdrop-blur-xs transition-colors"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Tap Zones for Next/Prev */}
          <div
            onClick={handlePrevStory}
            className="absolute left-0 top-16 bottom-24 w-1/3 z-20 cursor-pointer"
          />
          <div
            onClick={handleNextStory}
            className="absolute right-0 top-16 bottom-24 w-2/3 z-20 cursor-pointer"
          />

          {/* Media Image */}
          <div className="relative w-full h-full flex-1 bg-neutral-900 flex items-center justify-center">
            <img
              src={activeStory.mediaUrl}
              alt="Story"
              className="w-full h-full object-cover"
            />

            {/* Sticker Badge Overlay */}
            {activeStory.sticker && (
              <div className="absolute top-20 right-4 px-3 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-[#FF9933]/50 text-[#FF9933] text-xs font-bold shadow-lg animate-bounce">
                {activeStory.sticker}
              </div>
            )}

            {/* Spotify Music Badge Overlay */}
            {activeStory.audioTrack && (
              <div className="absolute top-20 left-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-orange-300/40 text-orange-200 text-[11px] font-medium flex items-center gap-1.5 shadow-md">
                <div className="w-3.5 h-3.5 rounded-full bg-[#1DB954] flex items-center justify-center text-white flex-shrink-0">
                  <svg className="w-2 h-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.061-.779-.179-.839-.539-.06-.421.18-.78.54-.84 4.56-1.021 8.52-.6 11.64 1.32.42.18.48.66.241 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
                  </svg>
                </div>
                <Music className="w-3 h-3 text-[#FF9933]" />
                <span className="truncate max-w-[140px]">{activeStory.audioTrack}</span>
              </div>
            )}

            {/* Caption Banner */}
            {activeStory.caption && (
              <div className="absolute bottom-20 left-3 right-3 p-3 rounded-xl bg-black/60 backdrop-blur-md border border-white/15 text-white text-xs font-medium text-center leading-relaxed shadow-lg">
                {activeStory.caption}
              </div>
            )}

            {/* Heart Animation on Reaction */}
            <AnimatePresence>
              {showHeartAnim && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1.5, opacity: 1 }}
                  exit={{ scale: 2, opacity: 0 }}
                  className="absolute z-40 text-6xl pointer-events-none drop-shadow-2xl"
                >
                  ❤️
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Story Bottom Bar: Quick Indian Reactions & DM Reply */}
          <div className="relative z-30 p-3 bg-black/80 backdrop-blur-md border-t border-white/10 flex flex-col gap-2">
            {/* Quick Desi Emoji Bar */}
            <div className="flex items-center justify-around py-1 text-lg">
              {['🙏', '❤️', '🔥', '☕', '👏', '🪔'].map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleQuickReaction(emoji)}
                  className="hover:scale-125 active:scale-95 transition-transform p-1"
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Message Input Box */}
            <form onSubmit={handleSendReply} className="flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder={`Reply to ${activeStory.username}...`}
                className="flex-1 bg-white/10 border border-white/20 rounded-full px-4 py-2 text-xs text-white placeholder-white/60 focus:outline-none focus:border-[#FF9933]"
              />
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="p-2 rounded-full bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white disabled:opacity-40 hover:opacity-90 transition-opacity shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>

        {/* Navigation Arrows for Desktop */}
        {currentIndex > 0 && (
          <button
            onClick={handlePrevStory}
            className="hidden md:block absolute left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-white transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}
        {currentIndex < selectedStory.stories.length - 1 && (
          <button
            onClick={handleNextStory}
            className="hidden md:block absolute right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-white transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>
    </AnimatePresence>
  );
};
