import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Reel, Comment } from '../types';
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  Volume2,
  VolumeX,
  Music,
  Plus,
  Check,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Repeat,
  Play,
  Pause,
  Flame,
  X,
  Smile,
  Share2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';
import { RepostModal } from './RepostModal';
import { generateDynamicDesiReel } from '../data/initialData';

export const ReelsView: React.FC = () => {
  const {
    reels: contextReels,
    currentUser,
    toggleFollowUser,
    users,
    setSelectedChat,
    chats,
    setActiveTab,
    triggerDesiCelebration,
  } = useApp();

  // Infinite Reels Stream State
  const [reelStream, setReelStream] = useState<Reel[]>(() => {
    // Start with context reels + 3 extra dynamically synthesized reels
    const initial = [...contextReels];
    for (let i = 0; i < 3; i++) {
      initial.push(generateDynamicDesiReel(initial.length + i));
    }
    return initial;
  });

  const [activeReelIndex, setActiveReelIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [likedReelIds, setLikedReelIds] = useState<string[]>(['reel_arnav', 'reel_1', 'reel_2']);
  const [savedReelIds, setSavedReelIds] = useState<string[]>(['reel_arnav', 'reel_2']);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [isRepostOpen, setIsRepostOpen] = useState(false);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState(false);

  // Comments for the active reel
  const [reelComments, setReelComments] = useState<Record<string, Comment[]>>({
    reel_arnav: [
      {
        id: 'rc_1',
        userId: 'user_priya',
        username: 'priya.in.saree',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
        text: 'Super high energy! Love the Diwali sparkler creativity Arnav! 🪔✨',
        timestamp: '1h ago',
        likesCount: 14,
        isLiked: true,
        isVerified: true,
      },
      {
        id: 'rc_2',
        userId: 'user_rohan',
        username: 'rohan_beats',
        userAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80',
        text: 'The background Lo-Fi synth is totally vibing with the visual! 🔥',
        timestamp: '30m ago',
        likesCount: 8,
        isLiked: false,
      },
    ],
    reel_1: [
      {
        id: 'rc_3',
        userId: 'user_current',
        username: 'kabir_clicks',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
        text: 'What a rhythm bro! Mumbai monsoons & tabla is match made in heaven 🥁🌧️',
        timestamp: '2h ago',
        likesCount: 21,
        isLiked: true,
      },
    ],
  });
  const [commentInput, setCommentInput] = useState('');

  // Touch and scroll tracking
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const touchStartY = useRef<number>(0);
  const isScrolling = useRef<boolean>(false);
  const lastTapRef = useRef<number>(0);

  // Synchronize new reels created in context
  useEffect(() => {
    if (contextReels.length > 0) {
      setReelStream((prev) => {
        const existingIds = new Set(prev.map((r) => r.id));
        const newOnes = contextReels.filter((r) => !existingIds.has(r.id));
        if (newOnes.length > 0) {
          return [...newOnes, ...prev];
        }
        return prev;
      });
    }
  }, [contextReels]);

  // Infinite loader: when active index is within 2 of end, generate 4 more reels!
  const ensureMoreReels = useCallback((targetIndex: number) => {
    if (targetIndex >= reelStream.length - 2) {
      setReelStream((prev) => {
        const nextBatch: Reel[] = [];
        for (let i = 0; i < 4; i++) {
          nextBatch.push(generateDynamicDesiReel(prev.length + i));
        }
        return [...prev, ...nextBatch];
      });
    }
  }, [reelStream.length]);

  const activeReel = reelStream[activeReelIndex] || reelStream[0];

  const handleNextReel = useCallback(() => {
    if (isScrolling.current) return;
    isScrolling.current = true;
    const nextIdx = activeReelIndex + 1;
    ensureMoreReels(nextIdx);
    setActiveReelIndex(nextIdx);
    setIsPlaying(true);
    setTimeout(() => {
      isScrolling.current = false;
    }, 350);
  }, [activeReelIndex, ensureMoreReels]);

  const handlePrevReel = useCallback(() => {
    if (isScrolling.current) return;
    if (activeReelIndex > 0) {
      isScrolling.current = true;
      setActiveReelIndex((prev) => prev - 1);
      setIsPlaying(true);
      setTimeout(() => {
        isScrolling.current = false;
      }, 350);
    }
  }, [activeReelIndex]);

  // Wheel / Trackpad smooth swipe detection
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (isCommentsOpen || isShareModalOpen || isRepostOpen) return;
    if (Math.abs(e.deltaY) < 30) return;
    if (e.deltaY > 0) {
      handleNextReel();
    } else if (e.deltaY < 0) {
      handlePrevReel();
    }
  };

  // Touch Swipe for Mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (isCommentsOpen || isShareModalOpen || isRepostOpen) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY;
    if (diff > 50) {
      // Swiped UP -> Next reel
      handleNextReel();
    } else if (diff < -50) {
      // Swiped DOWN -> Prev reel
      handlePrevReel();
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isCommentsOpen || isShareModalOpen || isRepostOpen) return;
      if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault();
        handleNextReel();
      } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
        e.preventDefault();
        handlePrevReel();
      } else if (e.key === 'm' || e.key === 'M') {
        setIsMuted((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNextReel, handlePrevReel, isCommentsOpen, isShareModalOpen, isRepostOpen]);

  // Auto-scroll loop if enabled
  useEffect(() => {
    if (!autoScrollEnabled) return;
    const timer = setTimeout(() => {
      handleNextReel();
    }, 9000);
    return () => clearTimeout(timer);
  }, [autoScrollEnabled, activeReelIndex, handleNextReel]);

  // Double-tap on video to Like
  const handleVideoClick = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap detected!
      if (!likedReelIds.includes(activeReel.id)) {
        toggleLike(activeReel.id);
      } else {
        // Show burst anyway for delight
        setShowHeartBurst(true);
        setTimeout(() => setShowHeartBurst(false), 800);
      }
    } else {
      // Single tap -> Toggle play/pause
      setIsPlaying((prev) => {
        if (videoRef.current) {
          if (prev) {
            videoRef.current.pause();
          } else {
            videoRef.current.play().catch(() => {});
          }
        }
        return !prev;
      });
    }
    lastTapRef.current = now;
  };

  const toggleLike = (reelId: string) => {
    const isLiked = likedReelIds.includes(reelId);
    if (!isLiked) {
      setLikedReelIds((prev) => [...prev, reelId]);
      setShowHeartBurst(true);
      confetti({
        particleCount: 35,
        spread: 60,
        origin: { y: 0.65 },
        colors: ['#EC4899', '#FF9933', '#10B981', '#F59E0B'],
      });
      setTimeout(() => setShowHeartBurst(false), 800);
    } else {
      setLikedReelIds((prev) => prev.filter((id) => id !== reelId));
    }
  };

  const toggleSave = (reelId: string) => {
    setSavedReelIds((prev) =>
      prev.includes(reelId) ? prev.filter((id) => id !== reelId) : [...prev, reelId]
    );
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;

    const newC: Comment = {
      id: `rc_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      text: commentInput.trim(),
      timestamp: 'Just now',
      likesCount: 0,
      isLiked: false,
    };

    setReelComments((prev) => ({
      ...prev,
      [activeReel.id]: [...(prev[activeReel.id] || []), newC],
    }));

    setCommentInput('');
    confetti({
      particleCount: 15,
      spread: 30,
      colors: ['#FF9933', '#10B981'],
    });
  };

  const handleQuickDesiComment = (text: string) => {
    const newC: Comment = {
      id: `rc_${Date.now()}`,
      userId: currentUser.id,
      username: currentUser.username,
      userAvatar: currentUser.avatar,
      text,
      timestamp: 'Just now',
      likesCount: 1,
      isLiked: true,
    };

    setReelComments((prev) => ({
      ...prev,
      [activeReel.id]: [...(prev[activeReel.id] || []), newC],
    }));

    confetti({
      particleCount: 20,
      spread: 40,
      colors: ['#FF9933', '#F59E0B'],
    });
  };

  const isAuthorFollowing = (userId: string) => {
    const u = users.find((usr) => usr.id === userId);
    return u?.isFollowing;
  };

  const authorUser = users.find((u) => u.id === activeReel.userId);
  const isVerifiedAuthor = authorUser?.isVerified ?? true;
  const currentReelComments = reelComments[activeReel.id] || [];
  const totalCommentsCount = activeReel.commentsCount + currentReelComments.length;

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="relative w-full max-w-md mx-auto h-[calc(100vh-125px)] max-h-[750px] bg-neutral-950 rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl flex flex-col my-1 select-none"
    >
      {/* Background Video Stream */}
      <div
        onClick={handleVideoClick}
        className="relative w-full h-full bg-neutral-900 flex items-center justify-center overflow-hidden cursor-pointer"
      >
        <video
          ref={videoRef}
          key={activeReel.id}
          src={activeReel.videoUrl}
          poster={activeReel.thumbnailUrl}
          autoPlay
          loop
          muted={isMuted}
          playsInline
          className="w-full h-full object-cover"
        />

        {/* Gradient overlays for contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/85 pointer-events-none" />

        {/* Paused Indicator Icon */}
        {!isPlaying && (
          <div className="absolute z-25 p-4 rounded-full bg-black/60 text-white backdrop-blur-md animate-in fade-in zoom-in-75">
            <Pause className="w-8 h-8" />
          </div>
        )}

        {/* Double-Tap Big Heart Burst */}
        <AnimatePresence>
          {showHeartBurst && (
            <motion.div
              initial={{ scale: 0, opacity: 0, rotate: -15 }}
              animate={{ scale: 1.6, opacity: 1, rotate: 0 }}
              exit={{ scale: 2.2, opacity: 0, rotate: 15 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="absolute z-35 text-8xl pointer-events-none drop-shadow-2xl flex items-center justify-center"
            >
              ❤️
            </motion.div>
          )}
        </AnimatePresence>

        {/* Top Header Controls */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-auto"
        >
          {/* Reel Index & Unlimited Badge */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/55 backdrop-blur-md border border-orange-300/40 text-orange-200 text-xs font-bold shadow-lg">
            <Sparkles className="w-3.5 h-3.5 text-[#FF9933] animate-spin-slow" />
            <span>Reel #{activeReelIndex + 1}</span>
            <span className="text-[10px] text-orange-300/80 bg-orange-500/20 px-1.5 py-0.5 rounded-md font-mono">
              ∞ Unlimited
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Auto-scroll toggle */}
            <button
              onClick={() => {
                setAutoScrollEnabled(!autoScrollEnabled);
                if (!autoScrollEnabled) triggerDesiCelebration();
              }}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold backdrop-blur-md border transition-all flex items-center gap-1 ${
                autoScrollEnabled
                  ? 'bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white border-transparent shadow-md'
                  : 'bg-black/50 text-neutral-300 border-white/10 hover:bg-black/70'
              }`}
              title="Auto-Scroll next reel automatically"
            >
              <Flame className="w-3.5 h-3.5 text-amber-300" />
              <span>{autoScrollEnabled ? 'Auto ON' : 'Auto Play'}</span>
            </button>

            {/* Mute/Unmute */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-full bg-black/50 text-white backdrop-blur-md border border-white/10 hover:bg-black/70 transition-colors shadow-md"
              title={isMuted ? 'Unmute (M)' : 'Mute (M)'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>
          </div>
        </div>

        {/* Floating Vertical Navigation Arrows */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute top-1/2 left-3 -translate-y-1/2 z-20 flex flex-col gap-2 pointer-events-auto"
        >
          {activeReelIndex > 0 && (
            <button
              onClick={handlePrevReel}
              className="p-2 rounded-full bg-black/50 backdrop-blur-md text-white border border-white/10 hover:bg-black/70 transition-all hover:scale-110 shadow-lg"
              title="Previous Reel (Arrow Up / Scroll Up)"
            >
              <ChevronUp className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={handleNextReel}
            className="p-2 rounded-full bg-gradient-to-b from-[#FF9933] to-[#D97706] backdrop-blur-md text-white border border-orange-300/40 hover:opacity-90 transition-all hover:scale-110 shadow-lg"
            title="Next Reel (Arrow Down / Scroll Down / Swipe Up)"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>

        {/* Right Rail Interaction Column */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute right-3 bottom-14 z-20 flex flex-col items-center gap-3.5 pointer-events-auto"
        >
          {/* Like */}
          <button
            onClick={() => toggleLike(activeReel.id)}
            className="flex flex-col items-center gap-1 group focus:outline-none"
            title="Like Reel"
          >
            <div className="p-2.5 rounded-full bg-black/45 backdrop-blur-md border border-white/15 group-hover:scale-110 transition-transform shadow-lg">
              <Heart
                className={`w-6 h-6 ${
                  likedReelIds.includes(activeReel.id)
                    ? 'fill-rose-500 text-rose-500'
                    : 'text-white'
                }`}
              />
            </div>
            <span className="text-[11px] font-bold text-white drop-shadow">
              {(activeReel.likesCount + (likedReelIds.includes(activeReel.id) ? 1 : 0)).toLocaleString()}
            </span>
          </button>

          {/* Repost Button */}
          <button
            onClick={() => setIsRepostOpen(true)}
            className="flex flex-col items-center gap-1 group focus:outline-none"
            title="Repost Reel on Public Bharat Feed"
          >
            <div className="p-2.5 rounded-full bg-black/45 backdrop-blur-md border border-white/15 group-hover:scale-110 group-hover:rotate-180 transition-all shadow-lg text-[#FF9933]">
              <Repeat className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-white drop-shadow">
              Repost
            </span>
          </button>

          {/* Comments Drawer Button */}
          <button
            onClick={() => setIsCommentsOpen(true)}
            className="flex flex-col items-center gap-1 group focus:outline-none"
            title="Desi Comments"
          >
            <div className="p-2.5 rounded-full bg-black/45 backdrop-blur-md border border-white/15 group-hover:scale-110 transition-transform shadow-lg">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-[11px] font-bold text-white drop-shadow">
              {totalCommentsCount}
            </span>
          </button>

          {/* Share to Chat & Social */}
          <button
            onClick={() => setIsShareModalOpen(true)}
            className="flex flex-col items-center gap-1 group focus:outline-none"
            title="Share Reel"
          >
            <div className="p-2.5 rounded-full bg-black/45 backdrop-blur-md border border-white/15 group-hover:scale-110 transition-transform shadow-lg">
              <Send className="w-5 h-5 text-white" />
            </div>
            <span className="text-[11px] font-bold text-white drop-shadow">
              {activeReel.sharesCount}
            </span>
          </button>

          {/* Bookmark / Save */}
          <button
            onClick={() => toggleSave(activeReel.id)}
            className="flex flex-col items-center gap-1 group focus:outline-none"
            title="Save to Collection"
          >
            <div className="p-2.5 rounded-full bg-black/45 backdrop-blur-md border border-white/15 group-hover:scale-110 transition-transform shadow-lg">
              <Bookmark
                className={`w-5 h-5 ${
                  savedReelIds.includes(activeReel.id)
                    ? 'fill-[#FF9933] text-[#FF9933]'
                    : 'text-white'
                }`}
              />
            </div>
          </button>

          {/* Spinning Audio Vinyl Disc */}
          <div className="relative w-9 h-9 rounded-full bg-neutral-900 border-2 border-orange-300/40 p-0.5 flex items-center justify-center animate-spin-slow shadow-md">
            <img
              src={activeReel.userAvatar}
              alt="Track Cover"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        </div>

        {/* Bottom Left Reel Information */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute left-3 right-16 bottom-3.5 z-20 text-white space-y-2 pointer-events-auto"
        >
          {/* Creator Profile & Follow */}
          <div className="flex items-center gap-2 flex-wrap">
            <img
              src={activeReel.userAvatar}
              alt={activeReel.username}
              className="w-9 h-9 rounded-full object-cover border-2 border-[#FF9933] shadow-md"
            />
            <div className="flex items-center gap-1">
              <span className="text-xs font-bold text-white drop-shadow-md">
                @{activeReel.username}
              </span>
              {isVerifiedAuthor && <DesiVerifiedBadge size="xs" />}
            </div>

            {activeReel.userId !== currentUser.id && (
              <button
                onClick={() => toggleFollowUser(activeReel.userId)}
                className={`px-3 py-1 rounded-full text-xs font-bold border transition-all shadow-sm ${
                  isAuthorFollowing(activeReel.userId)
                    ? 'bg-neutral-800/80 border-neutral-600 text-neutral-300'
                    : 'bg-gradient-to-r from-[#FF9933] to-[#D97706] border-transparent text-white'
                }`}
              >
                {isAuthorFollowing(activeReel.userId) ? (
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3" /> Dost
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Plus className="w-3 h-3" /> + Follow
                  </span>
                )}
              </button>
            )}
          </div>

          {/* Caption */}
          <p className="text-xs text-neutral-100 line-clamp-2 leading-relaxed drop-shadow-md font-medium">
            {activeReel.caption}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-1">
            {activeReel.tags.map((tag, idx) => (
              <span key={idx} className="text-[10px] font-bold text-orange-300 drop-shadow">
                {tag}
              </span>
            ))}
          </div>

          {/* Audio Track Banner with Spotify integration indicator */}
          <div className="flex items-center gap-2 text-[11px] text-orange-200">
            <div className="w-3.5 h-3.5 rounded-full bg-[#1DB954] flex items-center justify-center text-white flex-shrink-0">
              <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.061-.779-.179-.839-.539-.06-.421.18-.78.54-.84 4.56-1.021 8.52-.6 11.64 1.32.42.18.48.66.241 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
              </svg>
            </div>
            <Music className="w-3.5 h-3.5 text-[#FF9933] animate-spin-slow flex-shrink-0" />
            <span className="truncate font-medium">
              {activeReel.audioTrack.title} • {activeReel.audioTrack.artist}
            </span>
          </div>
        </div>
      </div>

      {/* COMMENTS BOTTOM SHEET / DRAWER */}
      <AnimatePresence>
        {isCommentsOpen && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="absolute inset-x-0 bottom-0 top-24 z-40 bg-neutral-900/95 backdrop-blur-xl rounded-t-3xl border-t border-neutral-700 p-4 flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#FF9933]" />
                <h3 className="text-sm font-bold text-white">
                  Desi Comments ({totalCommentsCount})
                </h3>
              </div>
              <button
                onClick={() => setIsCommentsOpen(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Desi Praise Buttons */}
            <div className="py-2.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-neutral-800/80">
              {['Zabardast! 🔥', 'Waah waah! 🪔', 'Gazab video! 👏', 'Pure Sukoon ☕', 'Jiyo re Sher! 🦁'].map(
                (phrase) => (
                  <button
                    key={phrase}
                    onClick={() => handleQuickDesiComment(phrase)}
                    className="px-2.5 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-orange-200 text-xs font-semibold whitespace-nowrap border border-neutral-700 transition-colors"
                  >
                    {phrase}
                  </button>
                )
              )}
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto py-3 space-y-3">
              {currentReelComments.length === 0 ? (
                <div className="py-12 text-center text-xs text-neutral-400">
                  Be the first to drop a sweet Desi comment on this Reel! 🪔
                </div>
              ) : (
                currentReelComments.map((c) => (
                  <div key={c.id} className="flex items-start gap-2.5">
                    <img
                      src={c.userAvatar}
                      alt={c.username}
                      className="w-7 h-7 rounded-full object-cover border border-neutral-700 flex-shrink-0 mt-0.5"
                    />
                    <div className="flex-1 bg-neutral-800/60 rounded-2xl p-2.5 border border-neutral-700/60">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-bold text-neutral-200">@{c.username}</span>
                        <span className="text-[10px] text-neutral-400">{c.timestamp}</span>
                      </div>
                      <p className="text-xs text-neutral-300 leading-relaxed">{c.text}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Comment Input */}
            <form onSubmit={handleAddComment} className="pt-2 flex items-center gap-2 border-t border-neutral-800">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Add a Desi comment..."
                className="flex-1 bg-neutral-800 border border-neutral-700 rounded-full px-4 py-2 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-[#FF9933]"
              />
              <button
                type="submit"
                disabled={!commentInput.trim()}
                className="p-2 rounded-full bg-gradient-to-r from-[#FF9933] to-[#D97706] text-white disabled:opacity-40 transition-opacity shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SHARE MODAL */}
      <AnimatePresence>
        {isShareModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700 rounded-3xl p-5 space-y-4 text-white animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Share2 className="w-5 h-5 text-[#FF9933]" />
                  <h3 className="text-sm font-bold">Share Reel</h3>
                </div>
                <button
                  onClick={() => setIsShareModalOpen(false)}
                  className="p-1 rounded-full hover:bg-neutral-800 text-neutral-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-neutral-400">
                Share "{activeReel.caption.slice(0, 45)}..." with friends on Instagram Lite Bharat
              </p>

              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {chats.map((chat) => (
                  <div
                    key={chat.id}
                    onClick={() => {
                      setSelectedChat(chat);
                      setActiveTab('messages');
                      setIsShareModalOpen(false);
                      triggerDesiCelebration();
                    }}
                    className="p-2.5 rounded-2xl bg-neutral-800/80 hover:bg-neutral-700 flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={chat.participant.avatar}
                        alt={chat.participant.name}
                        className="w-8 h-8 rounded-full object-cover border border-neutral-600"
                      />
                      <div>
                        <p className="text-xs font-bold text-neutral-200">{chat.participant.name}</p>
                        <p className="text-[10px] text-neutral-400">@{chat.participant.username}</p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#FF9933]">Send →</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  navigator.clipboard?.writeText?.(window.location.href);
                  triggerDesiCelebration();
                  setIsShareModalOpen(false);
                }}
                className="w-full py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-neutral-200 border border-neutral-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>📋 Copy Reel Link</span>
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Repost Modal */}
      <RepostModal
        reel={activeReel}
        isOpen={isRepostOpen}
        onClose={() => setIsRepostOpen(false)}
      />
    </div>
  );
};
