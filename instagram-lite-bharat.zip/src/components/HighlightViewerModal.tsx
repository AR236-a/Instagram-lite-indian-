import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, ChevronLeft, ChevronRight, Music, Heart, Sparkles, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';

export const HighlightViewerModal: React.FC = () => {
  const { selectedHighlight, setSelectedHighlight, currentUser, deleteStoryHighlight } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!selectedHighlight) {
      setCurrentIndex(0);
      setProgress(0);
      return;
    }

    const stories = selectedHighlight.stories || [];
    if (stories.length === 0) return;

    if (isPaused) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((idx) => idx + 1);
            return 0;
          } else {
            setSelectedHighlight(null);
            return 0;
          }
        }
        return prev + 2.5; // ~4 seconds per story
      });
    }, 100);

    return () => clearInterval(interval);
  }, [selectedHighlight, currentIndex, isPaused, setSelectedHighlight]);

  if (!selectedHighlight) return null;

  const stories = selectedHighlight.stories && selectedHighlight.stories.length > 0
    ? selectedHighlight.stories
    : [
        {
          id: 'hl_def',
          userId: currentUser.id,
          username: currentUser.username,
          userAvatar: currentUser.avatar,
          mediaUrl: selectedHighlight.cover,
          mediaType: 'image' as const,
          caption: `${selectedHighlight.title} memories! 🪔`,
          sticker: selectedHighlight.icon,
          audioTrack: 'Chai & Monsoons Acoustic',
          timestamp: 'Highlight',
          viewersCount: 340,
        },
      ];

  const activeStory = stories[currentIndex] || stories[0];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      setProgress(0);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((i) => i + 1);
      setProgress(0);
    } else {
      setSelectedHighlight(null);
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    deleteStoryHighlight(selectedHighlight.id);
    setSelectedHighlight(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 select-none">
      <div
        className="relative w-full h-full sm:h-[90vh] sm:max-w-md bg-neutral-900 sm:rounded-3xl overflow-hidden flex flex-col justify-between shadow-2xl border border-white/10"
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Top Progress Bars */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1.5">
          {stories.map((s, idx) => (
            <div key={s.id || idx} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#FF9933] to-[#D97706] rounded-full transition-all duration-75"
                style={{
                  width:
                    idx < currentIndex
                      ? '100%'
                      : idx === currentIndex
                      ? `${progress}%`
                      : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Top Header */}
        <div className="absolute top-6 left-4 right-4 z-30 flex items-center justify-between text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#FF9933] to-[#D97706] p-0.5 flex items-center justify-center">
              <img
                src={selectedHighlight.cover}
                alt={selectedHighlight.title}
                className="w-full h-full rounded-full object-cover border border-white"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white drop-shadow-md">{selectedHighlight.title}</span>
                <DesiVerifiedBadge size="xs" />
              </div>
              <p className="text-[10px] text-orange-200 font-medium">
                Story Highlight • @{currentUser.username}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleDelete}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-rose-400 transition-colors"
              title="Delete this Highlight"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setSelectedHighlight(null)}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Nav Touch Zones */}
        <div className="absolute inset-0 z-20 flex">
          <div className="w-1/3 h-full cursor-pointer" onClick={handlePrev} />
          <div className="w-2/3 h-full cursor-pointer" onClick={handleNext} />
        </div>

        {/* Media */}
        <div className="relative w-full h-full flex-1 bg-neutral-950 flex items-center justify-center">
          <img
            src={activeStory.mediaUrl}
            alt="Highlight Story"
            className="w-full h-full object-cover"
          />

          {/* Sticker */}
          {activeStory.sticker && (
            <div className="absolute top-20 right-4 px-3 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-[#FF9933]/50 text-[#FF9933] text-xs font-bold shadow-lg animate-bounce">
              {activeStory.sticker}
            </div>
          )}

          {/* Music */}
          {activeStory.audioTrack && (
            <div className="absolute top-20 left-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-orange-300/40 text-orange-200 text-[11px] font-medium flex items-center gap-1.5 shadow-md">
              <Music className="w-3.5 h-3.5 text-[#FF9933]" />
              <span>{activeStory.audioTrack}</span>
            </div>
          )}

          {/* Caption */}
          {activeStory.caption && (
            <div className="absolute bottom-16 left-4 right-4 p-3 rounded-2xl bg-black/65 backdrop-blur-md border border-white/15 text-white text-xs font-medium text-center shadow-lg leading-relaxed">
              {activeStory.caption}
            </div>
          )}
        </div>

        {/* Bottom Banner */}
        <div className="relative z-30 p-3 bg-black/80 backdrop-blur-md border-t border-white/10 flex items-center justify-between text-xs text-white">
          <div className="flex items-center gap-2">
            <span className="text-base">{selectedHighlight.icon}</span>
            <span className="font-bold text-orange-200">{selectedHighlight.title}</span>
          </div>
          <span className="text-[11px] text-gray-400">
            {currentIndex + 1} / {stories.length}
          </span>
        </div>
      </div>
    </div>
  );
};
