import React, { useState } from 'react';
import { Post } from '../types';
import { useApp } from '../context/AppContext';
import { Heart, MessageCircle, Send, Bookmark, MapPin, Music2, MoreHorizontal, Repeat, Volume2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CommentsModal } from './CommentsModal';
import { RepostModal } from './RepostModal';
import { DesiVerifiedBadge } from './DesiVerifiedBadge';
import confetti from 'canvas-confetti';

interface PostCardProps {
  post: Post;
  onUserClick?: (userId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onUserClick }) => {
  const {
    toggleLikePost,
    toggleSavePost,
    addCommentToPost,
    currentUser,
    users,
    t,
    setSelectedChat,
    chats,
    setActiveTab,
  } = useApp();

  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showHeartAnim, setShowHeartAnim] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [isRepostModalOpen, setIsRepostModalOpen] = useState(false);
  const [lastTap, setLastTap] = useState(0);

  const postAuthor = users.find((u) => u.id === post.userId) || (post.userId === currentUser.id ? currentUser : null);
  const isVerifiedUser = postAuthor?.isVerified || post.username.includes('priya') || post.username.includes('ananya') || post.username.includes('meera');

  const handleDoubleTap = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTap < DOUBLE_TAP_DELAY) {
      if (!post.isLiked) {
        toggleLikePost(post.id);
      }
      setShowHeartAnim(true);
      setTimeout(() => setShowHeartAnim(false), 900);
    }
    setLastTap(now);
  };

  const handleInlineCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    addCommentToPost(post.id, commentInput);
    setCommentInput('');
  };

  const handleQuickReaction = (text: string) => {
    addCommentToPost(post.id, text);
    confetti({
      particleCount: 15,
      spread: 30,
      origin: { y: 0.8 },
      colors: ['#FF9933', '#EC4899'],
    });
  };

  const handleShareToChat = (chatId: string) => {
    const chat = chats.find((c) => c.id === chatId);
    if (chat) {
      setSelectedChat(chat);
      setActiveTab('messages');
      setShowShareModal(false);
    }
  };

  return (
    <article className="w-full bg-white border border-orange-100/90 rounded-2xl mb-5 overflow-hidden shadow-xs hover:shadow-md transition-all">
      {/* Repost Header Banner (If this post is a repost) */}
      {post.isRepost && post.repostInfo && (
        <div className="px-4 py-2 bg-gradient-to-r from-orange-100/90 via-amber-50 to-orange-50 border-b border-orange-200/80 flex items-center justify-between text-xs text-orange-950 font-medium">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#D97706] text-white flex items-center justify-center text-[10px]">
              <Repeat className="w-3 h-3 stroke-[2.5]" />
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-gray-800">@{post.username}</span>
              <span className="text-[11px] text-gray-600">reposted from</span>
              <span className="font-bold text-[#D97706] flex items-center gap-1">
                @{post.repostInfo.originalUsername}
                <DesiVerifiedBadge size="xs" />
              </span>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-200/60 text-[#D97706] font-bold">
            Bharat Repost 🇮🇳
          </span>
        </div>
      )}

      {/* Post Top Author Header */}
      <div className="px-4 py-3 flex items-center justify-between border-b border-orange-50">
        <div
          onClick={() => onUserClick && onUserClick(post.userId)}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="relative w-9 h-9 rounded-full p-[1.5px] bg-gradient-to-tr from-[#FF9933] via-[#D97706] to-[#138808]">
            <img
              src={post.userAvatar}
              alt={post.username}
              className="w-full h-full rounded-full object-cover border border-white"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-gray-900 group-hover:text-[#D97706] transition-colors">
                {post.username}
              </span>
              {isVerifiedUser && <DesiVerifiedBadge size="xs" />}
              <span className="w-1 h-1 rounded-full bg-gray-300"></span>
              <span className="text-[10px] text-gray-400 font-medium">{post.timestamp}</span>
            </div>
            {post.location && (
              <div className="flex items-center gap-1 text-[11px] text-[#D97706] font-medium">
                <MapPin className="w-3 h-3 text-rose-500 flex-shrink-0" />
                <span className="truncate max-w-[200px]">{post.location}</span>
              </div>
            )}
          </div>
        </div>

        <button
          onClick={() => setIsCommentsOpen(true)}
          className="text-gray-400 hover:text-gray-700 p-1.5 rounded-lg hover:bg-orange-50 transition-colors"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
      </div>

      {/* Spotify & Indian Audio Track Tag Bar (if present) */}
      {post.audioTrack && (
        <div
          onClick={() => setIsPlayingAudio(!isPlayingAudio)}
          className="px-4 py-1.5 bg-gradient-to-r from-[#1DB954]/10 via-[#FFF9F2] to-orange-50/80 border-b border-orange-100/70 flex items-center justify-between text-xs cursor-pointer hover:bg-orange-50 transition-colors"
        >
          <div className="flex items-center gap-2 min-w-0">
            {/* Spotify Green Badge */}
            <div className="w-4 h-4 rounded-full bg-[#1DB954] text-white flex items-center justify-center flex-shrink-0">
              <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.061-.779-.179-.839-.539-.06-.421.18-.78.54-.84 4.56-1.021 8.52-.6 11.64 1.32.42.18.48.66.241 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
              </svg>
            </div>
            <span className="text-[11px] font-bold text-gray-900 truncate">
              {post.audioTrack.title}
            </span>
            <span className="text-[10px] text-gray-500 truncate">
              • {post.audioTrack.artist}
            </span>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0">
            <div className="flex items-center gap-0.5">
              <div className={`w-1 h-2.5 bg-[#1DB954] rounded-full ${isPlayingAudio ? 'animate-pulse' : 'opacity-40'}`} />
              <div className={`w-1 h-4 bg-[#FF9933] rounded-full ${isPlayingAudio ? 'animate-pulse delay-75' : 'opacity-40'}`} />
              <div className={`w-1 h-3 bg-[#1DB954] rounded-full ${isPlayingAudio ? 'animate-pulse delay-150' : 'opacity-40'}`} />
            </div>
            <span className="text-[10px] text-[#15803D] font-bold">
              {isPlayingAudio ? 'Playing' : 'Spotify'}
            </span>
          </div>
        </div>
      )}

      {/* Post Media Photo (with double-tap to heart) */}
      <div
        onClick={handleDoubleTap}
        className="relative w-full aspect-square bg-gray-50 overflow-hidden flex items-center justify-center select-none cursor-pointer"
      >
        <img
          src={post.mediaUrl}
          alt={post.caption}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-[1.01]"
          style={{ filter: post.filter || 'none' }}
        />

        {/* Desi Stickers placed on post */}
        {post.desiStickers &&
          post.desiStickers.map((st) => (
            <div
              key={st.id}
              className="absolute text-3xl drop-shadow-md pointer-events-none select-none"
              style={{ left: `${st.x}%`, top: `${st.y}%` }}
            >
              {st.emoji}
            </div>
          ))}

        {/* Double-Tap Heart Animation */}
        <AnimatePresence>
          {showHeartAnim && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1.4, opacity: 1 }}
              exit={{ scale: 2, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="absolute z-20 pointer-events-none drop-shadow-2xl"
            >
              <Heart className="w-24 h-24 fill-rose-500 text-rose-500" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Buttons Row */}
      <div className="px-4 pt-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => toggleLikePost(post.id)}
            className="group flex items-center gap-1 focus:outline-none"
            title="Like this Desi post"
          >
            <Heart
              className={`w-6 h-6 transition-all duration-200 group-hover:scale-110 ${
                post.isLiked
                  ? 'fill-rose-500 text-rose-500'
                  : 'text-gray-700 hover:text-rose-500'
              }`}
            />
          </button>

          <button
            onClick={() => setIsCommentsOpen(true)}
            className="group text-gray-700 hover:text-[#D97706] transition-colors"
            title="Comments & Charcha"
          >
            <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </button>

          {/* Repost to Feed Button */}
          <button
            onClick={() => setIsRepostModalOpen(true)}
            className="group text-gray-700 hover:text-[#D97706] transition-colors flex items-center gap-1"
            title="Repost on your public account"
          >
            <Repeat className="w-5 h-5 group-hover:scale-110 group-hover:rotate-180 transition-transform duration-300" />
            <span className="text-[11px] font-bold text-gray-500 group-hover:text-[#D97706]">Repost</span>
          </button>

          <button
            onClick={() => setShowShareModal(true)}
            className="group text-gray-700 hover:text-[#D97706] transition-colors"
            title="Share with Desi Friends"
          >
            <Send className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </button>
        </div>

        <button
          onClick={() => toggleSavePost(post.id)}
          className="text-gray-700 hover:text-[#D97706] transition-colors"
          title="Save to Bharat collection"
        >
          <Bookmark
            className={`w-6 h-6 transition-all ${
              post.isSaved
                ? 'fill-[#D97706] text-[#D97706]'
                : 'hover:scale-110'
            }`}
          />
        </button>
      </div>

      {/* Likes Count */}
      <div className="px-4 pt-2 flex items-center justify-between">
        <p className="text-xs font-bold text-gray-900">
          {post.likesCount.toLocaleString()} likes
        </p>
        <span className="text-[11px] text-gray-400 font-medium">
          🇮🇳 100% Desi Organic
        </span>
      </div>

      {/* Caption & Poetic Shayari */}
      <div className="px-4 pt-1.5 space-y-1.5">
        <p className="text-xs text-gray-800 leading-relaxed">
          <span
            onClick={() => onUserClick && onUserClick(post.userId)}
            className="font-bold text-gray-900 hover:text-[#D97706] mr-1.5 cursor-pointer"
          >
            {post.username}
          </span>
          {post.caption}
        </p>

        {/* Poetic Desi Shayari Couplet */}
        {post.shayari && (
          <div className="p-2.5 rounded-xl bg-orange-50/80 border border-orange-200/70 text-[11px] text-orange-950 italic font-serif leading-relaxed">
            <span className="text-[#D97706] font-bold not-italic mr-1">🪔 Sher:</span>
            "{post.shayari}"
          </div>
        )}

        {/* Hashtags */}
        {post.hashtags && post.hashtags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-0.5">
            {post.hashtags.map((tag, idx) => (
              <span
                key={idx}
                className="text-[11px] font-semibold text-[#D97706] hover:underline cursor-pointer"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Quick Desi Comment Pills */}
      <div className="px-4 pt-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {['Kadak click bhai! ☕🔥', 'Sundar picture ✨', 'Kya baat hai! 👏', 'Hero entry 😎'].map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleQuickReaction(chip)}
            className="px-2.5 py-1 rounded-full bg-orange-50 hover:bg-orange-100 text-orange-900 text-[10px] font-medium whitespace-nowrap border border-orange-200/70 transition-all active:scale-95"
          >
            {chip}
          </button>
        ))}
      </div>

      {/* Comments Count / View All */}
      {post.comments.length > 0 && (
        <div className="px-4 pt-2">
          <button
            onClick={() => setIsCommentsOpen(true)}
            className="text-[11px] text-gray-500 hover:text-gray-800 font-medium"
          >
            {t('view_all_comments')} ({post.comments.length})
          </button>
        </div>
      )}

      {/* Inline Quick Add Comment Box */}
      <form
        onSubmit={handleInlineCommentSubmit}
        className="px-4 py-2.5 mt-2 border-t border-orange-100 bg-[#FFFAF5] flex items-center gap-2.5"
      >
        <img
          src={currentUser.avatar}
          alt={currentUser.username}
          className="w-6 h-6 rounded-full object-cover flex-shrink-0 border border-orange-200"
        />
        <input
          type="text"
          value={commentInput}
          onChange={(e) => setCommentInput(e.target.value)}
          placeholder={t('add_comment')}
          className="flex-1 bg-transparent text-xs text-gray-800 placeholder-gray-400 focus:outline-none"
        />
        {commentInput.trim() && (
          <button
            type="submit"
            className="text-xs font-bold text-[#D97706] hover:text-orange-700 transition-colors"
          >
            Post
          </button>
        )}
      </form>

      {/* Comments Modal */}
      <CommentsModal
        post={post}
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
      />

      {/* Repost Modal */}
      <RepostModal
        post={post}
        isOpen={isRepostModalOpen}
        onClose={() => setIsRepostModalOpen(false)}
      />

      {/* Quick Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white border border-orange-100 rounded-2xl p-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-orange-100">
              <span className="text-xs font-bold text-gray-900">Share to Desi DMs 💬</span>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-gray-400 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="py-3 space-y-2 max-h-60 overflow-y-auto">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => handleShareToChat(chat.id)}
                  className="flex items-center justify-between p-2 rounded-xl hover:bg-orange-50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={chat.participantAvatar}
                      alt={chat.participantName}
                      className="w-8 h-8 rounded-full object-cover border border-orange-200"
                    />
                    <div>
                      <p className="text-xs font-bold text-gray-900">{chat.participantName}</p>
                      <p className="text-[10px] text-gray-500">@{chat.participantUsername}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-[#D97706]">Send →</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </article>
  );
};
