import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, MessageCircle, Heart, Bell, Globe, Search, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    language,
    setLanguage,
    chats,
    isFestiveMode,
    toggleFestiveMode,
    showContactLogin,
    setShowContactLogin,
    appPermissions,
    t,
  } = useApp();

  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const totalUnread = chats.reduce((acc, c) => acc + c.unreadCount, 0);

  const notifications = [
    {
      id: 'n1',
      user: 'priya.in.saree',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      action: 'liked your chai photo ☕',
      time: '12m ago',
    },
    {
      id: 'n2',
      user: 'delhi_foodie_ananya',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      action: 'commented: "Arey yaar craving ho gayi! 🤤"',
      time: '1h ago',
    },
    {
      id: 'n3',
      user: 'aarav_wanderlust',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      action: 'started following you 🇮🇳',
      time: '3h ago',
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-orange-100 shadow-xs px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Logo with Saffron-Amber Gradient */}
        <div
          onClick={() => setActiveTab('feed')}
          className="flex items-center gap-2.5 cursor-pointer select-none group"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#FF9933] to-[#D97706] flex items-center justify-center shadow-sm shadow-orange-500/20 group-hover:scale-105 transition-transform flex-shrink-0">
            <div className="w-4 h-4 border-2 border-white rounded-full flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full" />
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-serif font-bold bg-gradient-to-r from-[#FF9933] to-[#D97706] bg-clip-text text-transparent">
                Instagram Lite
              </span>
              <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-orange-50 text-[#D97706] border border-orange-200">
                Bharat
              </span>
            </div>
            <span className="text-[10px] text-gray-500 -mt-0.5 font-medium">
              Made with Desi Pyaar ❤️
            </span>
          </div>
        </div>

        {/* Search Bar on Medium/Desktop */}
        <div
          onClick={() => setActiveTab('explore')}
          className="hidden md:flex items-center gap-2 px-4 py-1.5 bg-[#FFFAF5] hover:bg-orange-50 border border-orange-100 rounded-full cursor-pointer transition-colors w-64"
        >
          <Search className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-xs text-gray-400 font-normal">Search friends, chai, places...</span>
        </div>

        {/* Right Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Contact Login / Device Permissions Button */}
          <button
            onClick={() => setShowContactLogin(true)}
            title="My Contact Login & Device Permissions"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-semibold bg-[#FFFAF5] hover:bg-orange-50 text-[#D97706] border border-orange-200 transition-all shadow-2xs"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {appPermissions.contacts ? 'Contacts Linked' : 'Link Contacts'}
            </span>
          </button>

          {/* Festive Mode Utsav Sparkler Button */}
          <button
            onClick={toggleFestiveMode}
            title={t('festive_mode')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-semibold border transition-all ${
              isFestiveMode
                ? 'bg-orange-50 text-[#D97706] border-orange-300 shadow-sm shadow-orange-500/20 animate-pulse'
                : 'bg-[#FFFAF5] text-gray-600 border-orange-100 hover:bg-orange-50 hover:text-gray-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FF9933] animate-spin-slow" />
            <span className="hidden sm:inline">Utsav Sparkle</span>
          </button>

          {/* Quick Language Selector */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#FFFAF5] hover:bg-orange-50 text-xs text-gray-700 border border-orange-100 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#FF9933]" />
              <span className="uppercase font-bold text-[11px]">{language}</span>
            </button>

            <AnimatePresence>
              {showLangMenu && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-40 bg-white border border-orange-100 rounded-2xl shadow-xl shadow-orange-950/5 py-1 z-50 overflow-hidden"
                >
                  <button
                    onClick={() => {
                      setLanguage('hinglish');
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-orange-50 ${
                      language === 'hinglish' ? 'text-[#D97706] font-bold bg-orange-50/70' : 'text-gray-700'
                    }`}
                  >
                    <span>Hinglish 🇮🇳</span>
                    {language === 'hinglish' && <span className="text-[#D97706] text-xs">✓</span>}
                  </button>
                  <button
                    onClick={() => {
                      setLanguage('hi');
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-orange-50 ${
                      language === 'hi' ? 'text-[#D97706] font-bold bg-orange-50/70' : 'text-gray-700'
                    }`}
                  >
                    <span>हिन्दी (Hindi)</span>
                    {language === 'hi' && <span className="text-[#D97706] text-xs">✓</span>}
                  </button>
                  <button
                    onClick={() => {
                      setLanguage('en');
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-orange-50 ${
                      language === 'en' ? 'text-[#D97706] font-bold bg-orange-50/70' : 'text-gray-700'
                    }`}
                  >
                    <span>English</span>
                    {language === 'en' && <span className="text-[#D97706] text-xs">✓</span>}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Notifications / Activity */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-xl bg-[#FFFAF5] hover:bg-orange-50 text-gray-700 border border-orange-100 transition-colors relative"
            >
              <Heart className="w-4 h-4 text-rose-500" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white"></span>
            </button>

            <AnimatePresence>
              {showNotifications && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-72 bg-white border border-orange-100 rounded-2xl shadow-xl shadow-orange-950/10 py-2 z-50"
                >
                  <div className="px-3.5 py-2 border-b border-orange-100 flex items-center justify-between bg-[#FFFAF5]">
                    <span className="text-xs font-bold text-gray-800">Desi Activity & Likes</span>
                    <span className="text-[10px] text-[#D97706] font-bold">New 🪔</span>
                  </div>
                  <div className="divide-y divide-orange-50 max-h-64 overflow-y-auto">
                    {notifications.map((n) => (
                      <div key={n.id} className="p-2.5 flex items-center gap-2.5 hover:bg-orange-50/50">
                        <img src={n.avatar} alt={n.user} className="w-8 h-8 rounded-full object-cover border border-orange-200" />
                        <div className="flex-1 text-xs">
                          <p className="text-gray-800">
                            <span className="font-bold text-gray-900">@{n.user}</span> {n.action}
                          </p>
                          <span className="text-[10px] text-gray-400">{n.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Direct Messages (Baatcheet) */}
          <button
            onClick={() => setActiveTab('messages')}
            className={`relative p-2 rounded-xl border transition-colors ${
              activeTab === 'messages'
                ? 'bg-orange-100/70 border-orange-300 text-[#D97706]'
                : 'bg-[#FFFAF5] hover:bg-orange-50 border-orange-100 text-gray-700'
            }`}
            title={t('messages')}
          >
            <MessageCircle className="w-4 h-4 text-[#FF9933]" />
            {totalUnread > 0 && (
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-rose-500 to-amber-500 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {totalUnread}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

