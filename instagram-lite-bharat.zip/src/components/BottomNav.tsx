import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Compass, PlusSquare, Clapperboard, User as UserIcon } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, t } = useApp();

  const navItems = [
    {
      id: 'feed',
      label: t('home'),
      icon: Home,
    },
    {
      id: 'explore',
      label: t('explore'),
      icon: Compass,
    },
    {
      id: 'create',
      label: t('create'),
      icon: PlusSquare,
      isSpecial: true,
    },
    {
      id: 'reels',
      label: t('reels'),
      icon: Clapperboard,
    },
    {
      id: 'profile',
      label: t('profile'),
      icon: UserIcon,
      isProfile: true,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-orange-100 px-2 py-1.5 transition-all shadow-lg shadow-orange-950/5">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;

          if (item.isSpecial) {
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab('create')}
                className="group relative flex flex-col items-center justify-center p-1 focus:outline-none"
              >
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#FF9933] to-[#D97706] p-[1.5px] shadow-md shadow-orange-500/20 group-hover:scale-105 active:scale-95 transition-all">
                  <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center group-hover:bg-orange-50 transition-colors">
                    <PlusSquare className="w-5 h-5 text-[#D97706]" />
                  </div>
                </div>
                <span className="text-[10px] font-bold text-[#D97706] mt-0.5">
                  {item.label}
                </span>
              </button>
            );
          }

          if (item.isProfile) {
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab('profile')}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
                  isActive ? 'text-[#D97706] font-bold' : 'text-gray-500 hover:text-gray-900'
                }`}
              >
                <div className={`w-6 h-6 rounded-full p-[1.5px] ${isActive ? 'bg-gradient-to-tr from-[#FF9933] to-[#D97706]' : 'bg-transparent'}`}>
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.username}
                    className="w-full h-full rounded-full object-cover border border-white"
                  />
                </div>
                <span className="text-[10px] mt-1 tracking-tight">{item.label}</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
                isActive ? 'text-[#D97706] font-bold' : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-[#D97706] stroke-[2.5]' : 'stroke-[1.8]'}`} />
              <span className="text-[10px] mt-1 tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

