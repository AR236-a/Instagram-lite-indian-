import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { StoriesBar } from './components/StoriesBar';
import { StoryViewer } from './components/StoryViewer';
import { PostCard } from './components/PostCard';
import { ReelsView } from './components/ReelsView';
import { ExploreView } from './components/ExploreView';
import { DirectMessages } from './components/DirectMessages';
import { CreatePostModal } from './components/CreatePostModal';
import { ProfileView } from './components/ProfileView';
import { ContactLoginModal } from './components/ContactLoginModal';
import { HighlightViewerModal } from './components/HighlightViewerModal';
import { FollowersManagementModal } from './components/FollowersManagementModal';
import { Coffee, Sparkles, Flame, Users, TrendingUp, MapPin } from 'lucide-react';
import confetti from 'canvas-confetti';

const MainAppContent: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    posts,
    currentUser,
    users,
    followUser,
    showContactLogin,
    setShowContactLogin,
    selectedHighlight,
    setSelectedHighlight,
    t,
  } = useApp();

  const [selectedUserForProfile, setSelectedUserForProfile] = useState<string | null>(null);

  const handlePostUserClick = (userId: string) => {
    setActiveTab('profile');
  };

  const suggestedUsers = users.filter((u) => u.id !== currentUser.id && !u.isFollowing).slice(0, 4);

  return (
    <div className="min-h-screen bg-[#FFF9F2] text-gray-900 flex flex-col font-sans relative selection:bg-[#FF9933] selection:text-white">
      {/* Top Navbar */}
      <Navbar />

      {/* Main Container Area */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-2 sm:px-6 pt-4 pb-20">
        {/* Dynamic Tab Content */}
        {activeTab === 'feed' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left/Center Main Feed Column */}
            <div className="lg:col-span-2 max-w-xl mx-auto w-full">
              {/* Cultural Greeting & Chai Vibe Bar */}
              <div className="mb-4 px-4 py-3 rounded-2xl bg-[#FFFAF5] border border-orange-100 flex items-center justify-between shadow-xs">
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">🙏</span>
                  <div>
                    <p className="text-xs font-bold text-gray-900">
                      Namaste, {currentUser.name.split(' ')[0]}!
                    </p>
                    <p className="text-[10px] text-gray-500 font-medium">
                      4,210 desi clicks shared today across Bharat 🇮🇳
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    confetti({
                      particleCount: 30,
                      spread: 60,
                      colors: ['#FF9933', '#EC4899', '#10B981'],
                    });
                  }}
                  className="px-3 py-1.5 rounded-full bg-white hover:bg-orange-50 text-[10px] font-bold text-[#D97706] border border-orange-200/80 flex items-center gap-1.5 shadow-xs transition-all active:scale-95"
                >
                  <Coffee className="w-3.5 h-3.5 text-[#FF9933]" />
                  <span>Chai Cheer ☕</span>
                </button>
              </div>

              {/* Indian Stories Carousel */}
              <StoriesBar onAddStoryClick={() => setActiveTab('create')} />

              {/* Posts Feed Stream */}
              <div className="space-y-4">
                {posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    onUserClick={handlePostUserClick}
                  />
                ))}
              </div>
            </div>

            {/* Desktop Right Sidebar Widget */}
            <div className="hidden lg:block space-y-4">
              {/* Current User Quick Summary */}
              <div className="bg-white border border-orange-100 rounded-2xl p-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.username}
                      className="w-11 h-11 rounded-full object-cover border-2 border-orange-200"
                    />
                    <div>
                      <p className="text-xs font-bold text-gray-900">{currentUser.name}</p>
                      <p className="text-[11px] text-gray-500">@{currentUser.username}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('profile')}
                    className="text-xs font-bold text-[#D97706] hover:underline"
                  >
                    Switch
                  </button>
                </div>
              </div>

              {/* Desi Creators Suggestions */}
              <div className="bg-white border border-orange-100 rounded-2xl p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-gray-800">Suggested Desi Creators</span>
                  <button
                    onClick={() => setActiveTab('explore')}
                    className="text-[11px] font-semibold text-[#D97706] hover:underline"
                  >
                    See All
                  </button>
                </div>

                <div className="space-y-3">
                  {suggestedUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-8 h-8 rounded-full object-cover border border-orange-200"
                        />
                        <div className="text-xs">
                          <p className="font-bold text-gray-900 truncate max-w-[110px]">{user.name}</p>
                          <p className="text-[10px] text-gray-400">@{user.username}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => followUser(user.id)}
                        className="px-3 py-1 rounded-full bg-orange-50 hover:bg-orange-100 text-[#D97706] text-xs font-bold transition-colors border border-orange-200/80"
                      >
                        Follow
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trending Desi Hashtags */}
              <div className="bg-white border border-orange-100 rounded-2xl p-4 shadow-xs">
                <div className="flex items-center gap-1.5 mb-2.5">
                  <TrendingUp className="w-4 h-4 text-[#FF9933]" />
                  <span className="text-xs font-bold text-gray-800">Trending in Bharat</span>
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between text-gray-700 hover:text-[#D97706] cursor-pointer">
                    <span className="font-semibold">#ChaiPeCharcha</span>
                    <span className="text-[10px] text-gray-400">42.5k posts</span>
                  </div>
                  <div className="flex items-center justify-between text-gray-700 hover:text-[#D97706] cursor-pointer">
                    <span className="font-semibold">#RoyalRajasthan</span>
                    <span className="text-[10px] text-gray-400">28.1k posts</span>
                  </div>
                  <div className="flex items-center justify-between text-gray-700 hover:text-[#D97706] cursor-pointer">
                    <span className="font-semibold">#SareeTwitter</span>
                    <span className="text-[10px] text-gray-400">19.4k posts</span>
                  </div>
                  <div className="flex items-center justify-between text-gray-700 hover:text-[#D97706] cursor-pointer">
                    <span className="font-semibold">#DesiStreetFood</span>
                    <span className="text-[10px] text-gray-400">54.2k posts</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'explore' && <ExploreView />}

        {activeTab === 'create' && <CreatePostModal />}

        {activeTab === 'reels' && <ReelsView />}

        {activeTab === 'messages' && <DirectMessages />}

        {activeTab === 'profile' && <ProfileView />}
      </main>

      {/* Story Viewer Overlay (Active when story is clicked) */}
      <StoryViewer />

      {/* Story Highlights Fullscreen Viewer Modal */}
      {selectedHighlight && (
        <HighlightViewerModal
          highlight={selectedHighlight}
          onClose={() => setSelectedHighlight(null)}
        />
      )}

      {/* Followers / Following / Contacts Modal */}
      <FollowersManagementModal />

      {/* Contact Login & Device Permissions Onboarding Modal */}
      <ContactLoginModal
        isOpen={showContactLogin}
        onClose={() => setShowContactLogin(false)}
      />

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}

